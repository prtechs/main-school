"use client"

import { useState } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, BookOpen, Send, Eye, Edit, Trash2, Clock, CheckCircle, AlertCircle, MessageSquare } from "lucide-react"

interface Homework {
  id: string
  title: string
  subject: string
  description: string
  class: string
  assignedDate: string
  dueDate: string
  assignedBy: string
  status: "draft" | "assigned" | "overdue"
  priority: "low" | "medium" | "high"
  attachments?: string[]
}

interface HomeworkNotification {
  id: string
  homeworkId: string
  sentAt: string
  recipientCount: number
  status: "sent" | "failed"
}

export function HomeworkSystem() {
  const { user } = useAuth()
  const [isAddHomeworkOpen, setIsAddHomeworkOpen] = useState(false)
  const [selectedHomework, setSelectedHomework] = useState<Homework | null>(null)
  const [showNotificationPreview, setShowNotificationPreview] = useState(false)
  const [activeTab, setActiveTab] = useState("assigned")

  // Mock homework data
  const [homeworkList, setHomeworkList] = useState<Homework[]>([
    {
      id: "1",
      title: "Mathematics Chapter 5 - Fractions",
      subject: "Mathematics",
      description: "Complete exercises 5.1 to 5.3 from the textbook. Show all working steps clearly.",
      class: "Class 5A",
      assignedDate: "2024-01-15",
      dueDate: "2024-01-18",
      assignedBy: "Sarah Johnson",
      status: "assigned",
      priority: "high",
    },
    {
      id: "2",
      title: "English Essay - My Favorite Season",
      subject: "English",
      description: "Write a 200-word essay about your favorite season. Include descriptive words and proper grammar.",
      class: "Class 5A",
      assignedDate: "2024-01-14",
      dueDate: "2024-01-20",
      assignedBy: "Sarah Johnson",
      status: "assigned",
      priority: "medium",
    },
    {
      id: "3",
      title: "Science Project - Solar System",
      subject: "Science",
      description: "Create a model of the solar system using recyclable materials. Prepare a 5-minute presentation.",
      class: "Class 5B",
      assignedDate: "2024-01-10",
      dueDate: "2024-01-25",
      assignedBy: "Sarah Johnson",
      status: "assigned",
      priority: "high",
    },
  ])

  const [notifications, setNotifications] = useState<HomeworkNotification[]>([
    {
      id: "1",
      homeworkId: "1",
      sentAt: "2024-01-15T10:30:00Z",
      recipientCount: 35,
      status: "sent",
    },
    {
      id: "2",
      homeworkId: "2",
      sentAt: "2024-01-14T14:15:00Z",
      recipientCount: 35,
      status: "sent",
    },
  ])

  const availableClasses =
    user?.role === "admin" ? ["Class 5A", "Class 5B", "Class 6A", "Class 6B"] : user?.classes || []

  const subjects = [
    "Mathematics",
    "English",
    "Science",
    "Social Studies",
    "Hindi",
    "Computer Science",
    "Art",
    "Physical Education",
  ]

  const filteredHomework = homeworkList.filter((homework) => {
    if (user?.role === "admin") return true
    return user?.classes.includes(homework.class)
  })

  const handleAddHomework = (formData: FormData) => {
    const newHomework: Homework = {
      id: Date.now().toString(),
      title: formData.get("title") as string,
      subject: formData.get("subject") as string,
      description: formData.get("description") as string,
      class: formData.get("class") as string,
      assignedDate: new Date().toISOString().split("T")[0],
      dueDate: formData.get("dueDate") as string,
      assignedBy: user?.name || "",
      status: "draft",
      priority: formData.get("priority") as "low" | "medium" | "high",
    }

    setHomeworkList([...homeworkList, newHomework])
    setIsAddHomeworkOpen(false)
  }

  const handleAssignHomework = (homeworkId: string) => {
    setHomeworkList((prev) => prev.map((hw) => (hw.id === homeworkId ? { ...hw, status: "assigned" as const } : hw)))

    // Simulate sending notifications
    const homework = homeworkList.find((hw) => hw.id === homeworkId)
    if (homework) {
      const newNotification: HomeworkNotification = {
        id: Date.now().toString(),
        homeworkId,
        sentAt: new Date().toISOString(),
        recipientCount: 35, // Mock count
        status: "sent",
      }
      setNotifications([...notifications, newNotification])
      setShowNotificationPreview(true)

      setTimeout(() => {
        setShowNotificationPreview(false)
      }, 5000)
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "assigned":
        return "bg-blue-100 text-blue-800"
      case "draft":
        return "bg-gray-100 text-gray-800"
      case "overdue":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getDaysUntilDue = (dueDate: string) => {
    const due = new Date(dueDate)
    const today = new Date()
    const diffTime = due.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Homework Management</h2>
          <p className="text-gray-600 mt-2">Assign homework and communicate with parents</p>
        </div>
        <Dialog open={isAddHomeworkOpen} onOpenChange={setIsAddHomeworkOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Homework
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Assign New Homework</DialogTitle>
              <DialogDescription>Create and assign homework to students</DialogDescription>
            </DialogHeader>
            <form action={handleAddHomework} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Homework Title</Label>
                  <Input id="title" name="title" placeholder="e.g., Mathematics Chapter 5" required />
                </div>
                <div>
                  <Label htmlFor="subject">Subject</Label>
                  <Select name="subject" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((subject) => (
                        <SelectItem key={subject} value={subject}>
                          {subject}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="class">Class</Label>
                  <Select name="class" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableClasses.map((className) => (
                        <SelectItem key={className} value={className}>
                          {className}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="dueDate">Due Date</Label>
                  <Input id="dueDate" name="dueDate" type="date" required />
                </div>
              </div>

              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select name="priority" defaultValue="medium">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low Priority</SelectItem>
                    <SelectItem value="medium">Medium Priority</SelectItem>
                    <SelectItem value="high">High Priority</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description">Description & Instructions</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="Provide detailed instructions for the homework..."
                  rows={4}
                  required
                />
              </div>

              <Button type="submit" className="w-full">
                Create Homework
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Notification Preview */}
      {showNotificationPreview && (
        <Alert className="border-green-200 bg-green-50">
          <Send className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            <strong>WhatsApp Notifications Sent!</strong> Parents have been notified about the new homework assignment.
            <br />
            <em>
              Example: "New homework assigned for Class 5A: Mathematics Chapter 5 - Fractions. Due: Jan 18, 2024. Check
              details in SchoolTrack app."
            </em>
          </AlertDescription>
        </Alert>
      )}

      {/* Homework Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600">Total Assigned</p>
                <p className="text-2xl font-bold">{filteredHomework.filter((hw) => hw.status === "assigned").length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-yellow-600" />
              <div>
                <p className="text-sm text-gray-600">Due This Week</p>
                <p className="text-2xl font-bold">
                  {
                    filteredHomework.filter((hw) => {
                      const daysUntil = getDaysUntilDue(hw.dueDate)
                      return daysUntil >= 0 && daysUntil <= 7
                    }).length
                  }
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <div>
                <p className="text-sm text-gray-600">High Priority</p>
                <p className="text-2xl font-bold">{filteredHomework.filter((hw) => hw.priority === "high").length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Notifications Sent</p>
                <p className="text-2xl font-bold">{notifications.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Homework Management Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="assigned">Assigned Homework</TabsTrigger>
          <TabsTrigger value="drafts">Drafts</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="assigned">
          <Card>
            <CardHeader>
              <CardTitle>Assigned Homework</CardTitle>
              <CardDescription>Currently active homework assignments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredHomework
                      .filter((hw) => hw.status === "assigned")
                      .map((homework) => {
                        const daysUntilDue = getDaysUntilDue(homework.dueDate)
                        return (
                          <TableRow key={homework.id}>
                            <TableCell>
                              <div>
                                <div className="font-medium">{homework.title}</div>
                                <div className="text-sm text-gray-500 truncate max-w-xs">{homework.description}</div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{homework.subject}</Badge>
                            </TableCell>
                            <TableCell>{homework.class}</TableCell>
                            <TableCell>
                              <div>
                                <div>{new Date(homework.dueDate).toLocaleDateString()}</div>
                                <div
                                  className={`text-xs ${
                                    daysUntilDue < 0
                                      ? "text-red-600"
                                      : daysUntilDue <= 2
                                        ? "text-yellow-600"
                                        : "text-gray-500"
                                  }`}
                                >
                                  {daysUntilDue < 0
                                    ? `${Math.abs(daysUntilDue)} days overdue`
                                    : daysUntilDue === 0
                                      ? "Due today"
                                      : `${daysUntilDue} days left`}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={getPriorityColor(homework.priority)}>{homework.priority}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge className={getStatusColor(homework.status)}>{homework.status}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button variant="ghost" size="sm" onClick={() => setSelectedHomework(homework)}>
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="drafts">
          <Card>
            <CardHeader>
              <CardTitle>Draft Homework</CardTitle>
              <CardDescription>Homework assignments ready to be assigned</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredHomework
                      .filter((hw) => hw.status === "draft")
                      .map((homework) => (
                        <TableRow key={homework.id}>
                          <TableCell className="font-medium">{homework.title}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{homework.subject}</Badge>
                          </TableCell>
                          <TableCell>{homework.class}</TableCell>
                          <TableCell>{new Date(homework.dueDate).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Badge className={getPriorityColor(homework.priority)}>{homework.priority}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button size="sm" onClick={() => handleAssignHomework(homework.id)}>
                                <Send className="h-4 w-4 mr-1" />
                                Assign & Notify
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-600">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
              {filteredHomework.filter((hw) => hw.status === "draft").length === 0 && (
                <div className="text-center py-8 text-gray-500">No draft homework assignments.</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification History</CardTitle>
              <CardDescription>WhatsApp notifications sent to parents</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {notifications.map((notification) => {
                  const homework = homeworkList.find((hw) => hw.id === notification.homeworkId)
                  return (
                    <div key={notification.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center justify-center w-10 h-10 bg-green-100 rounded-full">
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">{homework?.title}</p>
                          <p className="text-sm text-gray-500">
                            Sent to {notification.recipientCount} parents •{" "}
                            {new Date(notification.sentAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        {notification.status}
                      </Badge>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Homework Detail Modal */}
      {selectedHomework && (
        <Dialog open={!!selectedHomework} onOpenChange={() => setSelectedHomework(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedHomework.title}</DialogTitle>
              <DialogDescription>
                {selectedHomework.subject} • {selectedHomework.class}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <Badge className={getPriorityColor(selectedHomework.priority)}>{selectedHomework.priority}</Badge>
                <Badge className={getStatusColor(selectedHomework.status)}>{selectedHomework.status}</Badge>
                <span className="text-sm text-gray-500">
                  Due: {new Date(selectedHomework.dueDate).toLocaleDateString()}
                </span>
              </div>
              <div>
                <h4 className="font-medium mb-2">Instructions</h4>
                <p className="text-gray-700 whitespace-pre-wrap">{selectedHomework.description}</p>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setSelectedHomework(null)}>
                  Close
                </Button>
                <Button>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Homework
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
