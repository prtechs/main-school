"use client"

import type React from "react"

import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarInset,
} from "@/components/ui/sidebar"
import { Users, Calendar, BookOpen, BarChart3, Settings, LogOut, Bell, Home, UserCheck } from "lucide-react"
import Link from "next/link"
import { useRouter, usePathname } from "next/navigation"
import { useEffect } from "react"

interface DashboardLayoutProps {
  children: React.ReactNode
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { user, logout, isLoading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const navigationItems = [
    { icon: Home, label: "Dashboard", href: "/dashboard" },
    { icon: Users, label: "Students", href: "/dashboard/students" },
    { icon: Calendar, label: "Attendance", href: "/dashboard/attendance" },
    ...(user.role === "admin"
      ? [{ icon: UserCheck, label: "Teacher Attendance", href: "/dashboard/teacher-attendance" }]
      : []),
    { icon: BookOpen, label: "Homework", href: "/dashboard/homework" },
    { icon: Bell, label: "Meetings", href: "/dashboard/meetings" },
    { icon: BarChart3, label: "Reports", href: "/dashboard/reports" },
    ...(user.role === "admin" ? [{ icon: Settings, label: "Settings", href: "/dashboard/settings" }] : []),
  ]

  return (
    <SidebarProvider>
      <div className="min-h-screen bg-gray-50 flex w-full">
        <Sidebar variant="inset" collapsible="offcanvas">
          <SidebarHeader className="border-b border-gray-200 bg-white">
            <div className="flex items-center gap-2 px-4 py-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">ST</span>
                </div>
                <h1 className="text-xl font-bold text-blue-600 group-data-[collapsible=icon]:hidden">SchoolTrack</h1>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="bg-white">
            <SidebarMenu className="p-2">
              {navigationItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    asChild
                    isActive={pathname === item.href}
                    className="w-full justify-start hover:bg-blue-50 hover:text-blue-700 data-[active=true]:bg-blue-100 data-[active=true]:text-blue-700 data-[active=true]:font-medium py-3 px-4 text-base"
                  >
                    <Link href={item.href}>
                      <item.icon className="h-5 w-5" />
                      <span>{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="border-t border-gray-200 bg-white">
            <div className="p-4 space-y-2">
              <div className="text-sm text-gray-600 group-data-[collapsible=icon]:hidden">
                <div className="font-medium">{user.name}</div>
                <div className="capitalize">{user.role}</div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={logout}
                className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200 bg-transparent py-2 px-3"
              >
                <LogOut className="h-4 w-4 mr-2" />
                <span className="group-data-[collapsible=icon]:hidden">Logout</span>
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <SidebarInset className="flex flex-col">
          {/* Mobile/Desktop Header */}
          <header className="bg-white shadow-sm border-b sticky top-0 z-40">
            <div className="flex items-center justify-between px-4 py-3 md:px-6 md:py-4">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="md:hidden h-12 w-12 p-3 border-2 hover:bg-blue-50 hover:border-blue-300 transition-colors" />
                <div className="hidden md:block">
                  <h1 className="text-2xl font-bold text-blue-600">SchoolTrack</h1>
                </div>
                <div className="md:hidden">
                  <h1 className="text-lg font-bold text-blue-600">SchoolTrack</h1>
                </div>
                <div className="hidden sm:block text-sm text-gray-600">
                  Welcome back, <span className="font-medium">{user.name}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 md:gap-4">
                <div className="hidden md:block text-sm text-gray-600">
                  Role: <span className="font-medium capitalize">{user.role}</span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={logout}
                  className="md:hidden text-red-600 hover:text-red-700 bg-transparent h-10 w-10 p-2"
                >
                  <LogOut className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </header>

          <main className="flex-1 p-3 sm:p-4 md:p-6 overflow-auto">{children}</main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
