"use client"

import { useState } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Edit, Trash2, Users, GraduationCap, Phone, Mail, MoreVertical } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Student {
  id: string
  name: string
  rollNumber: string
  class: string
  parentName: string
  parentPhone: string
  parentEmail: string
  status: "active" | "inactive"
  admissionDate: string
}

interface Class {
  id: string
  name: string
  strength: number
  teacher: string
}

export function StudentManagement() {
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedClass, setSelectedClass] = useState("all")
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false)
  const [isAddClassOpen, setIsAddClassOpen] = useState(false)

  // Mock data - in real app, this would come from database
  const [students, setStudents] = useState<Student[]>([
    {
      id: "1",
      name: "Aarav Sharma",
      rollNumber: "5A001",
      class: "Class 5A",
      parentName: "Rajesh Sharma",
      parentPhone: "+91 9876543210",
      parentEmail: "rajesh.sharma@email.com",
      status: "active",
      admissionDate: "2023-04-15",
    },
    {
      id: "2",
      name: "Priya Patel",
      rollNumber: "5A002",
      class: "Class 5A",
      parentName: "Amit Patel",
      parentPhone: "+91 9876543211",
      parentEmail: "amit.patel@email.com",
      status: "active",
      admissionDate: "2023-04-16",
    },
    {
      id: "3",
      name: "Arjun Kumar",
      rollNumber: "5B001",
      class: "Class 5B",
      parentName: "Suresh Kumar",
      parentPhone: "+91 9876543212",
      parentEmail: "suresh.kumar@email.com",
      status: "active",
      admissionDate: "2023-04-17",
    },
    {
      id: "4",
      name: "Ananya Singh",
      rollNumber: "5B002",
      class: "Class 5B",
      parentName: "Vikram Singh",
      parentPhone: "+91 9876543213",
      parentEmail: "vikram.singh@email.com",
      status: "active",
      admissionDate: "2023-04-18",
    },
  ])

  const [classes, setClasses] = useState<Class[]>([
    { id: "1", name: "Class 5A", strength: 35, teacher: "Sarah Johnson" },
    { id: "2", name: "Class 5B", strength: 33, teacher: "Sarah Johnson" },
    { id: "3", name: "Class 6A", strength: 38, teacher: "Michael Brown" },
    { id: "4", name: "Class 6B", strength: 36, teacher: "Emily Davis" },
  ])

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.rollNumber.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesClass = selectedClass === "all" || student.class === selectedClass
    const matchesUserClasses = user?.role === "admin" || user?.classes.includes(student.class)

    return matchesSearch && matchesClass && matchesUserClasses
  })

  const availableClasses = user?.role === "admin" ? classes : classes.filter((cls) => user?.classes.includes(cls.name))

  const handleAddStudent = (formData: FormData) => {
    const newStudent: Student = {
      id: Date.now().toString(),
      name: formData.get("name") as string,
      rollNumber: formData.get("rollNumber") as string,
      class: formData.get("class") as string,
      parentName: formData.get("parentName") as string,
      parentPhone: formData.get("parentPhone") as string,
      parentEmail: formData.get("parentEmail") as string,
      status: "active",
      admissionDate: new Date().toISOString().split("T")[0],
    }
    setStudents([...students, newStudent])
    setIsAddStudentOpen(false)
  }

  const handleAddClass = (formData: FormData) => {
    const newClass: Class = {
      id: Date.now().toString(),
      name: formData.get("className") as string,
      strength: Number.parseInt(formData.get("strength") as string),
      teacher: formData.get("teacher") as string,
    }
    setClasses([...classes, newClass])
    setIsAddClassOpen(false)
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header - Made responsive with better mobile layout */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="px-1">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Student Management</h2>
          <p className="text-gray-600 mt-1 text-sm md:text-base">Manage students and class information</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          {user?.role === "admin" && (
            <>
              <Dialog open={isAddClassOpen} onOpenChange={setIsAddClassOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full sm:w-auto bg-transparent">
                    <GraduationCap className="h-4 w-4 mr-2" />
                    <span className="hidden sm:inline">Add Class</span>
                    <span className="sm:hidden">Class</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="w-[95vw] max-w-md mx-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Class</DialogTitle>
                    <DialogDescription>Create a new class in the school</DialogDescription>
                  </DialogHeader>
                  <form action={handleAddClass} className="space-y-4">
                    <div>
                      <Label htmlFor="className">Class Name</Label>
                      <Input id="className" name="className" placeholder="e.g., Class 7A" required />
                    </div>
                    <div>
                      <Label htmlFor="strength">Class Strength</Label>
                      <Input id="strength" name="strength" type="number" placeholder="35" required />
                    </div>
                    <div>
                      <Label htmlFor="teacher">Class Teacher</Label>
                      <Input id="teacher" name="teacher" placeholder="Teacher Name" required />
                    </div>
                    <Button type="submit" className="w-full">
                      Add Class
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>

              <Dialog open={isAddStudentOpen} onOpenChange={setIsAddStudentOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full sm:w-auto">
                    <Plus className="h-4 w-4 mr-2" />
                    <span className="hidden sm:inline">Add Student</span>
                    <span className="sm:hidden">Student</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="w-[95vw] max-w-md mx-auto max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Student</DialogTitle>
                    <DialogDescription>Add a new student to any class</DialogDescription>
                  </DialogHeader>
                  <form action={handleAddStudent} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Student Name</Label>
                      <Input id="name" name="name" placeholder="Full Name" required />
                    </div>
                    <div>
                      <Label htmlFor="rollNumber">Roll Number</Label>
                      <Input id="rollNumber" name="rollNumber" placeholder="e.g., 5A001" required />
                    </div>
                    <div>
                      <Label htmlFor="class">Class</Label>
                      <Select name="class" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select class" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableClasses.map((cls) => (
                            <SelectItem key={cls.id} value={cls.name}>
                              {cls.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="parentName">Parent Name</Label>
                      <Input id="parentName" name="parentName" placeholder="Parent/Guardian Name" required />
                    </div>
                    <div>
                      <Label htmlFor="parentPhone">Parent Phone</Label>
                      <Input id="parentPhone" name="parentPhone" placeholder="+91 9876543210" required />
                    </div>
                    <div>
                      <Label htmlFor="parentEmail">Parent Email</Label>
                      <Input id="parentEmail" name="parentEmail" type="email" placeholder="parent@email.com" required />
                    </div>
                    <Button type="submit" className="w-full">
                      Add Student
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </>
          )}
        </div>
      </div>

      {/* Class Overview Cards - Enhanced responsive grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-4">
        {availableClasses.map((cls) => (
          <Card key={cls.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-base md:text-lg truncate">{cls.name}</CardTitle>
              <CardDescription className="text-sm truncate">Teacher: {cls.teacher}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-blue-600 flex-shrink-0" />
                  <span className="text-xl md:text-2xl font-bold">{cls.strength}</span>
                </div>
                <Badge variant="secondary" className="text-xs">
                  Active
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Students Table - Made fully responsive with mobile-friendly design */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg md:text-xl">Students</CardTitle>
          <CardDescription className="text-sm">Manage student information and parent contacts</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filters - Improved mobile layout */}
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 mb-4 md:mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 text-sm md:text-base"
              />
            </div>
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {availableClasses.map((cls) => (
                  <SelectItem key={cls.id} value={cls.name}>
                    {cls.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Desktop Table View */}
          <div className="hidden md:block rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Roll No.</TableHead>
                  <TableHead>Class</TableHead>
                  <TableHead>Parent Contact</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{student.name}</div>
                        <div className="text-sm text-gray-500">
                          Admitted: {new Date(student.admissionDate).toLocaleDateString()}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono">{student.rollNumber}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{student.class}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">{student.parentName}</div>
                        <div className="flex items-center space-x-2 text-sm text-gray-500">
                          <Phone className="h-3 w-3" />
                          <span>{student.parentPhone}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-sm text-gray-500">
                          <Mail className="h-3 w-3" />
                          <span>{student.parentEmail}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={student.status === "active" ? "default" : "secondary"}>{student.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Mobile Card View - Added mobile-friendly card layout */}
          <div className="md:hidden space-y-3">
            {filteredStudents.map((student) => (
              <Card key={student.id} className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-gray-900 truncate">{student.name}</h3>
                    <p className="text-sm text-gray-500 font-mono">{student.rollNumber}</p>
                  </div>
                  <div className="flex items-center space-x-2 ml-2">
                    <Badge variant="outline" className="text-xs">
                      {student.class}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>

                <div className="space-y-2">
                  <div>
                    <p className="text-sm font-medium text-gray-700">{student.parentName}</p>
                    <div className="flex items-center space-x-1 text-xs text-gray-500">
                      <Phone className="h-3 w-3" />
                      <span>{student.parentPhone}</span>
                    </div>
                    <div className="flex items-center space-x-1 text-xs text-gray-500">
                      <Mail className="h-3 w-3" />
                      <span className="truncate">{student.parentEmail}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <Badge variant={student.status === "active" ? "default" : "secondary"} className="text-xs">
                      {student.status}
                    </Badge>
                    <span className="text-xs text-gray-500">
                      Admitted: {new Date(student.admissionDate).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {filteredStudents.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Users className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p>No students found matching your criteria.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
