"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, UserCheck, Calendar, Settings, Clock, AlertTriangle, TrendingUp, BookOpen } from "lucide-react"
import Link from "next/link"

interface QuickActionProps {
  title: string
  description: string
  icon: React.ReactNode
  href: string
  badge?: string
  badgeVariant?: "default" | "secondary" | "destructive" | "outline"
  urgent?: boolean
}

const QuickAction = ({ title, description, icon, href, badge, badgeVariant = "default", urgent }: QuickActionProps) => (
  <Link href={href}>
    <Card className={`hover:shadow-md transition-shadow cursor-pointer ${urgent ? "border-red-200 bg-red-50" : ""}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${urgent ? "bg-red-100 text-red-600" : "bg-blue-100 text-blue-600"}`}>
              {icon}
            </div>
            <div>
              <h3 className="font-semibold text-sm">{title}</h3>
              <p className="text-xs text-gray-600 mt-1">{description}</p>
            </div>
          </div>
          {badge && (
            <Badge variant={badgeVariant} className="text-xs">
              {badge}
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  </Link>
)

export default function QuickActions() {
  const [currentTime] = useState(new Date())
  const isAfterSchoolHours = currentTime.getHours() >= 15 // 3 PM
  const isWeekend = currentTime.getDay() === 0 || currentTime.getDay() === 6

  // Mock data for demonstration
  const pendingAttendance = 3
  const lateTeachers = 2
  const absentStudents = 12
  const upcomingMeetings = 1

  const quickActions: QuickActionProps[] = [
    {
      title: "Mark Student Attendance",
      description: "Record daily student attendance",
      icon: <Users className="h-4 w-4" />,
      href: "/dashboard/attendance",
      badge: pendingAttendance > 0 ? `${pendingAttendance} pending` : undefined,
      badgeVariant: "destructive",
      urgent: !isAfterSchoolHours && !isWeekend && pendingAttendance > 0,
    },
    {
      title: "Teacher Attendance",
      description: "Manage teacher attendance records",
      icon: <UserCheck className="h-4 w-4" />,
      href: "/dashboard/teacher-attendance",
      badge: lateTeachers > 0 ? `${lateTeachers} late` : undefined,
      badgeVariant: "outline",
    },
    {
      title: "View Reports",
      description: "Access attendance analytics",
      icon: <TrendingUp className="h-4 w-4" />,
      href: "/dashboard/reports",
      badge: "Updated",
    },
    {
      title: "Parent Meetings",
      description: "Schedule and manage meetings",
      icon: <Calendar className="h-4 w-4" />,
      href: "/dashboard/meetings",
      badge: upcomingMeetings > 0 ? `${upcomingMeetings} today` : undefined,
      badgeVariant: "secondary",
    },
    {
      title: "Student Management",
      description: "Add or edit student information",
      icon: <BookOpen className="h-4 w-4" />,
      href: "/dashboard/students",
    },
    {
      title: "Settings",
      description: "Configure school settings",
      icon: <Settings className="h-4 w-4" />,
      href: "/dashboard/settings",
    },
  ]

  const todayStats = [
    {
      label: "Present Students",
      value: "245",
      change: "+2%",
      positive: true,
    },
    {
      label: "Absent Students",
      value: absentStudents.toString(),
      change: "-5%",
      positive: true,
    },
    {
      label: "Teachers Present",
      value: "28",
      change: "100%",
      positive: true,
    },
    {
      label: "Late Arrivals",
      value: lateTeachers.toString(),
      change: "+1",
      positive: false,
    },
  ]

  return (
    <div className="space-y-6">
      {/* Today's Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Today's Overview
          </CardTitle>
          <CardDescription>
            {currentTime.toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {todayStats.map((stat, index) => (
              <div key={index} className="text-center p-3 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
                <div className={`text-xs ${stat.positive ? "text-green-600" : "text-red-600"}`}>{stat.change}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks and shortcuts for efficient school management</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quickActions.map((action, index) => (
              <QuickAction key={index} {...action} />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Urgent Notifications */}
      {(pendingAttendance > 0 || lateTeachers > 0) && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <AlertTriangle className="h-5 w-5" />
              Attention Required
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {pendingAttendance > 0 && (
                <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-orange-600" />
                    <span className="text-sm">{pendingAttendance} classes need attendance marking</span>
                  </div>
                  <Button size="sm" asChild>
                    <Link href="/dashboard/attendance">Mark Now</Link>
                  </Button>
                </div>
              )}
              {lateTeachers > 0 && (
                <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-orange-600" />
                    <span className="text-sm">{lateTeachers} teachers arrived late today</span>
                  </div>
                  <Button size="sm" variant="outline" asChild>
                    <Link href="/dashboard/teacher-attendance">View Details</Link>
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
