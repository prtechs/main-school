"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, User, Lock } from "lucide-react"
import { useAuth } from "./auth-provider"

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()
  const { login } = useAuth() // Using AuthProvider's login method

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Mock authentication - in real app, this would call an API
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Simulate API call

      if (email === "teacher@school.com" && password === "password") {
        const teacherUser = {
          id: "1",
          name: "Sarah Johnson",
          email: "teacher@school.com",
          role: "teacher" as const,
          classes: ["Class 5A", "Class 5B"],
        }
        login(teacherUser)
        router.push("/dashboard")
      } else if (email === "admin@school.com" && password === "password") {
        const adminUser = {
          id: "2",
          name: "John Smith",
          email: "admin@school.com",
          role: "admin" as const,
          classes: [],
        }
        login(adminUser)
        router.push("/dashboard")
      } else {
        setError("Invalid email or password")
      }
    } catch (err) {
      setError("Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const quickLogin = (userType: "teacher" | "admin") => {
    if (userType === "teacher") {
      setEmail("teacher@school.com")
      setPassword("password")
    } else {
      setEmail("admin@school.com")
      setPassword("password")
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <div className="relative">
          <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            id="email"
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="pl-10"
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <div className="relative">
          <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            id="password"
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="pl-10"
            required
          />
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Signing in...
          </>
        ) : (
          "Sign In"
        )}
      </Button>

      <div className="text-sm text-center text-gray-600 mt-4">
        <p className="mb-2">Demo Credentials:</p>
        <div className="flex gap-2 justify-center mb-2">
          <Button type="button" variant="outline" size="sm" onClick={() => quickLogin("teacher")} className="text-xs">
            Fill Teacher
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => quickLogin("admin")} className="text-xs">
            Fill Admin
          </Button>
        </div>
        <p>
          <strong>Teacher:</strong> teacher@school.com / password
        </p>
        <p>
          <strong>Admin:</strong> admin@school.com / password
        </p>
      </div>
    </form>
  )
}
