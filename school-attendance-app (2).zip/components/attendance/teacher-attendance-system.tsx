"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Save,
  BarChart3,
  Shield,
  AlertTriangle,
  MessageSquare,
} from "lucide-react"

interface Teacher {
  id: string
  name: string
  employeeId: string
  subject: string
  classes: string[]
  phone: string
}

interface TeacherAttendanceRecord {
  teacherId: string
  date: string
  status: "present" | "absent" | "late" | "leave" | "half-day-leave"
  markedAt: string
  markedBy: string
  checkInTime?: string
  checkOutTime?: string
  leaveReason?: string
  isLate?: boolean
}

interface MonthlyStats {
  teacherId: string
  month: string
  year: number
  totalWorkingDays: number
  presentDays: number
  absentDays: number
  lateDays: number
  leaveDays: number
  halfDayLeaveDays: number
  attendancePercentage: number
}

export function TeacherAttendanceSystem() {
  const { user } = useAuth()
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7))
  const [attendance, setAttendance] = useState<
    Record<string, "present" | "absent" | "late" | "leave" | "half-day-leave">
  >({})
  const [checkInTimes, setCheckInTimes] = useState<Record<string, string>>({})
  const [checkOutTimes, setCheckOutTimes] = useState<Record<string, string>>({})
  const [leaveReasons, setLeaveReasons] = useState<Record<string, string>>({})
  const [viewMode, setViewMode] = useState<"daily" | "monthly">("daily")
  const [isSaved, setIsSaved] = useState(false)
  const [lateMessages, setLateMessages] = useState<string[]>([])
  const [showLeaveDialog, setShowLeaveDialog] = useState<string | null>(null)

  // Mock teachers data
  const teachers: Teacher[] = [
    {
      id: "t1",
      name: "Dr. Rajesh Kumar",
      employeeId: "EMP001",
      subject: "Mathematics",
      classes: ["Class 5A", "Class 6A"],
      phone: "+91-9876543210",
    },
    {
      id: "t2",
      name: "Mrs. Priya Sharma",
      employeeId: "EMP002",
      subject: "English",
      classes: ["Class 5B", "Class 6B"],
      phone: "+91-9876543211",
    },
    {
      id: "t3",
      name: "Mr. Arun Singh",
      employeeId: "EMP003",
      subject: "Science",
      classes: ["Class 5A", "Class 5B"],
      phone: "+91-9876543212",
    },
    {
      id: "t4",
      name: "Ms. Kavya Reddy",
      employeeId: "EMP004",
      subject: "Hindi",
      classes: ["Class 6A", "Class 6B"],
      phone: "+91-9876543213",
    },
    {
      id: "t5",
      name: "Mr. Suresh Patel",
      employeeId: "EMP005",
      subject: "Social Studies",
      classes: ["Class 5A", "Class 6A"],
      phone: "+91-9876543214",
    },
  ]

  useEffect(() => {
    // Check if user is admin
    if (user?.role !== "admin") {
      return
    }

    // Load existing attendance for selected date
    const attendanceKey = `teacher-attendance-${selectedDate}`
    const existingAttendance = localStorage.getItem(attendanceKey)
    const existingCheckIn = localStorage.getItem(`teacher-checkin-${selectedDate}`)
    const existingCheckOut = localStorage.getItem(`teacher-checkout-${selectedDate}`)
    const existingLeaveReasons = localStorage.getItem(`teacher-leave-reasons-${selectedDate}`)

    if (existingAttendance) {
      setAttendance(JSON.parse(existingAttendance))
      setIsSaved(true)
    } else {
      setAttendance({})
      setIsSaved(false)
    }

    if (existingCheckIn) {
      setCheckInTimes(JSON.parse(existingCheckIn))
    } else {
      setCheckInTimes({})
    }

    if (existingCheckOut) {
      setCheckOutTimes(JSON.parse(existingCheckOut))
    } else {
      setCheckOutTimes({})
    }

    if (existingLeaveReasons) {
      setLeaveReasons(JSON.parse(existingLeaveReasons))
    } else {
      setLeaveReasons({})
    }
  }, [selectedDate])

  const handleAttendanceChange = (
    teacherId: string,
    status: "present" | "absent" | "late" | "leave" | "half-day-leave",
  ) => {
    setAttendance((prev) => ({
      ...prev,
      [teacherId]: status,
    }))
    setIsSaved(false)

    // Auto-set check-in time for present/late teachers
    if (status === "present" || status === "late") {
      const currentTime = new Date().toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      })
      setCheckInTimes((prev) => ({
        ...prev,
        [teacherId]: prev[teacherId] || currentTime,
      }))
    }

    if (status === "leave" || status === "half-day-leave") {
      setShowLeaveDialog(teacherId)
    }
  }

  const handleLeaveReasonSubmit = (teacherId: string, reason: string) => {
    setLeaveReasons((prev) => ({
      ...prev,
      [teacherId]: reason,
    }))
    setShowLeaveDialog(null)
    setIsSaved(false)
  }

  const handleCheckInTimeChange = (teacherId: string, time: string) => {
    setCheckInTimes((prev) => ({
      ...prev,
      [teacherId]: time,
    }))
    setIsSaved(false)

    const [hours, minutes] = time.split(":").map(Number)
    const checkInMinutes = hours * 60 + minutes
    const standardTime = 9 * 60 // 9:00 AM in minutes

    if (checkInMinutes > standardTime && attendance[teacherId] === "present") {
      // Auto-mark as late if checking in after 9:00 AM
      setAttendance((prev) => ({
        ...prev,
        [teacherId]: "late",
      }))
    }
  }

  const handleCheckOutTimeChange = (teacherId: string, time: string) => {
    setCheckOutTimes((prev) => ({
      ...prev,
      [teacherId]: time,
    }))
    setIsSaved(false)
  }

  const handleSaveAttendance = () => {
    const attendanceKey = `teacher-attendance-${selectedDate}`
    const checkInKey = `teacher-checkin-${selectedDate}`
    const checkOutKey = `teacher-checkout-${selectedDate}`
    const leaveReasonsKey = `teacher-leave-reasons-${selectedDate}`

    localStorage.setItem(attendanceKey, JSON.stringify(attendance))
    localStorage.setItem(checkInKey, JSON.stringify(checkInTimes))
    localStorage.setItem(checkOutKey, JSON.stringify(checkOutTimes))
    localStorage.setItem(leaveReasonsKey, JSON.stringify(leaveReasons))

    const lateTeachers = Object.entries(attendance)
      .filter(([_, status]) => status === "late")
      .map(([teacherId, _]) => {
        const teacher = teachers.find((t) => t.id === teacherId)
        const checkInTime = checkInTimes[teacherId]
        return `${teacher?.name} arrived late at ${checkInTime}`
      })

    setLateMessages(lateTeachers)
    setIsSaved(true)
  }

  const calculateCounts = () => {
    const present = Object.values(attendance).filter((status) => status === "present").length
    const absent = Object.values(attendance).filter((status) => status === "absent").length
    const late = Object.values(attendance).filter((status) => status === "late").length
    const leave = Object.values(attendance).filter((status) => status === "leave").length
    const halfDayLeave = Object.values(attendance).filter((status) => status === "half-day-leave").length
    return { present, absent, late, leave, halfDayLeave }
  }

  const calculateMonthlyStats = (teacherId: string): MonthlyStats => {
    const [year, month] = selectedMonth.split("-").map(Number)
    const daysInMonth = new Date(year, month, 0).getDate()

    let presentDays = 0
    let absentDays = 0
    let lateDays = 0
    let leaveDays = 0
    let halfDayLeaveDays = 0

    // Calculate stats from stored attendance data
    for (let day = 1; day <= daysInMonth; day++) {
      const date = `${year}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`
      const attendanceKey = `teacher-attendance-${date}`
      const dayAttendance = localStorage.getItem(attendanceKey)

      if (dayAttendance) {
        const parsedAttendance = JSON.parse(dayAttendance)
        const status = parsedAttendance[teacherId]

        if (status === "present") presentDays++
        else if (status === "absent") absentDays++
        else if (status === "late") lateDays++
        else if (status === "leave") leaveDays++
        else if (status === "half-day-leave") halfDayLeaveDays++
      }
    }

    const totalWorkingDays = 22 // Assuming 22 working days per month
    const attendancePercentage =
      totalWorkingDays > 0 ? ((presentDays + lateDays + halfDayLeaveDays * 0.5) / totalWorkingDays) * 100 : 0

    return {
      teacherId,
      month: selectedMonth,
      year,
      totalWorkingDays,
      presentDays,
      absentDays,
      lateDays,
      leaveDays,
      halfDayLeaveDays,
      attendancePercentage: Math.round(attendancePercentage * 100) / 100,
    }
  }

  const getStatusColor = (status: "present" | "absent" | "late" | "leave" | "half-day-leave") => {
    switch (status) {
      case "present":
        return "text-green-600 bg-green-50"
      case "absent":
        return "text-red-600 bg-red-50"
      case "late":
        return "text-yellow-600 bg-yellow-50"
      case "leave":
        return "text-blue-600 bg-blue-50"
      case "half-day-leave":
        return "text-purple-600 bg-purple-50"
    }
  }

  const getStatusIcon = (status: "present" | "absent" | "late" | "leave" | "half-day-leave") => {
    switch (status) {
      case "present":
        return <CheckCircle className="h-4 w-4" />
      case "absent":
        return <XCircle className="h-4 w-4" />
      case "late":
        return <Clock className="h-4 w-4" />
      case "leave":
        return <Calendar className="h-4 w-4" />
      case "half-day-leave":
        return <Calendar className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className="px-1">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Teacher Attendance System</h2>
        <p className="text-gray-600 mt-1 text-sm md:text-base">
          Manage daily teacher attendance with leave management and view monthly statistics (Admin Only)
        </p>
      </div>

      {/* View Mode Toggle */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg md:text-xl">View Mode</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Button
              variant={viewMode === "daily" ? "default" : "outline"}
              onClick={() => setViewMode("daily")}
              className="flex-1 sm:flex-none"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Daily Attendance
            </Button>
            <Button
              variant={viewMode === "monthly" ? "default" : "outline"}
              onClick={() => setViewMode("monthly")}
              className="flex-1 sm:flex-none"
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Monthly Stats
            </Button>
          </div>
        </CardContent>
      </Card>

      {user?.role === "admin" && (
        <>
          {viewMode === "daily" && (
            <>
              {/* Date Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg md:text-xl">Select Date</CardTitle>
                  <CardDescription>Choose the date for teacher attendance marking</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Date</label>
                      <input
                        type="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button
                        onClick={handleSaveAttendance}
                        disabled={Object.keys(attendance).length === 0}
                        className="w-full md:w-auto"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        {isSaved ? "Saved" : "Save Attendance"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {lateMessages.length > 0 && (
                <Alert className="border-yellow-200 bg-yellow-50">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  <AlertDescription className="text-yellow-800">
                    <strong>Late Arrivals Today:</strong>
                    <ul className="mt-2 space-y-1">
                      {lateMessages.map((message, index) => (
                        <li key={index} className="text-sm">
                          • {message}
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}

              {/* Attendance Summary */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4">
                <Card>
                  <CardContent className="p-3 md:p-4">
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs md:text-sm text-gray-600 truncate">Total</p>
                        <p className="text-lg md:text-2xl font-bold">{teachers.length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-3 md:p-4">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 md:h-5 md:w-5 text-green-600 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs md:text-sm text-gray-600 truncate">Present</p>
                        <p className="text-lg md:text-2xl font-bold text-green-600">{calculateCounts().present}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-3 md:p-4">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 md:h-5 md:w-5 text-yellow-600 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs md:text-sm text-gray-600 truncate">Late</p>
                        <p className="text-lg md:text-2xl font-bold text-yellow-600">{calculateCounts().late}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-3 md:p-4">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs md:text-sm text-gray-600 truncate">Leave</p>
                        <p className="text-lg md:text-2xl font-bold text-blue-600">{calculateCounts().leave}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-3 md:p-4">
                    <div className="flex items-center space-x-2">
                      <XCircle className="h-4 w-4 md:h-5 md:w-5 text-red-600 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs md:text-sm text-gray-600 truncate">Absent</p>
                        <p className="text-lg md:text-2xl font-bold text-red-600">{calculateCounts().absent}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Teacher Attendance Table */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg md:text-xl">Mark Teacher Attendance</CardTitle>
                  <CardDescription>
                    {new Date(selectedDate).toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Desktop Table View */}
                  <div className="hidden md:block rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Employee ID</TableHead>
                          <TableHead>Teacher Name</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Check In</TableHead>
                          <TableHead>Check Out</TableHead>
                          <TableHead>Leave Reason</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {teachers.map((teacher) => (
                          <TableRow key={teacher.id}>
                            <TableCell className="font-mono">{teacher.employeeId}</TableCell>
                            <TableCell className="font-medium">{teacher.name}</TableCell>
                            <TableCell>{teacher.subject}</TableCell>
                            <TableCell>
                              {attendance[teacher.id] ? (
                                <Badge variant="outline" className={getStatusColor(attendance[teacher.id])}>
                                  <div className="flex items-center space-x-1">
                                    {getStatusIcon(attendance[teacher.id])}
                                    <span className="capitalize">{attendance[teacher.id].replace("-", " ")}</span>
                                  </div>
                                </Badge>
                              ) : (
                                <Badge variant="secondary">Not Marked</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              {(attendance[teacher.id] === "present" || attendance[teacher.id] === "late") && (
                                <input
                                  type="time"
                                  value={checkInTimes[teacher.id] || ""}
                                  onChange={(e) => handleCheckInTimeChange(teacher.id, e.target.value)}
                                  className="text-xs border rounded px-2 py-1"
                                />
                              )}
                            </TableCell>
                            <TableCell>
                              {attendance[teacher.id] === "present" && (
                                <input
                                  type="time"
                                  value={checkOutTimes[teacher.id] || ""}
                                  onChange={(e) => handleCheckOutTimeChange(teacher.id, e.target.value)}
                                  className="text-xs border rounded px-2 py-1"
                                />
                              )}
                            </TableCell>
                            <TableCell>
                              {(attendance[teacher.id] === "leave" || attendance[teacher.id] === "half-day-leave") && (
                                <div className="flex items-center space-x-2">
                                  <span className="text-xs text-gray-600 truncate max-w-20">
                                    {leaveReasons[teacher.id] || "No reason"}
                                  </span>
                                  <Button size="sm" variant="ghost" onClick={() => setShowLeaveDialog(teacher.id)}>
                                    <MessageSquare className="h-3 w-3" />
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                <Button
                                  size="sm"
                                  variant={attendance[teacher.id] === "present" ? "default" : "outline"}
                                  onClick={() => handleAttendanceChange(teacher.id, "present")}
                                  className="text-xs"
                                >
                                  Present
                                </Button>
                                <Button
                                  size="sm"
                                  variant={attendance[teacher.id] === "late" ? "default" : "outline"}
                                  onClick={() => handleAttendanceChange(teacher.id, "late")}
                                  className="text-xs"
                                >
                                  Late
                                </Button>
                                <Button
                                  size="sm"
                                  variant={attendance[teacher.id] === "leave" ? "default" : "outline"}
                                  onClick={() => handleAttendanceChange(teacher.id, "leave")}
                                  className="text-xs"
                                >
                                  Leave
                                </Button>
                                <Button
                                  size="sm"
                                  variant={attendance[teacher.id] === "half-day-leave" ? "default" : "outline"}
                                  onClick={() => handleAttendanceChange(teacher.id, "half-day-leave")}
                                  className="text-xs"
                                >
                                  Half Day
                                </Button>
                                <Button
                                  size="sm"
                                  variant={attendance[teacher.id] === "absent" ? "destructive" : "outline"}
                                  onClick={() => handleAttendanceChange(teacher.id, "absent")}
                                  className="text-xs"
                                >
                                  Absent
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Mobile Card View */}
                  <div className="md:hidden space-y-3">
                    {teachers.map((teacher) => (
                      <Card key={teacher.id} className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-gray-900 truncate">{teacher.name}</h3>
                            <p className="text-sm text-gray-500">{teacher.subject}</p>
                            <p className="text-xs text-gray-400 font-mono">{teacher.employeeId}</p>
                          </div>
                          <div className="ml-2">
                            {attendance[teacher.id] ? (
                              <Badge variant="outline" className={`${getStatusColor(attendance[teacher.id])} text-xs`}>
                                <div className="flex items-center space-x-1">
                                  {getStatusIcon(attendance[teacher.id])}
                                  <span className="capitalize">{attendance[teacher.id].replace("-", " ")}</span>
                                </div>
                              </Badge>
                            ) : (
                              <Badge variant="secondary" className="text-xs">
                                Not Marked
                              </Badge>
                            )}
                          </div>
                        </div>

                        {/* Time inputs and leave reason for mobile */}
                        {(attendance[teacher.id] === "present" || attendance[teacher.id] === "late") && (
                          <div className="grid grid-cols-2 gap-2 mb-3">
                            <div>
                              <label className="text-xs text-gray-600">Check In</label>
                              <input
                                type="time"
                                value={checkInTimes[teacher.id] || ""}
                                onChange={(e) => handleCheckInTimeChange(teacher.id, e.target.value)}
                                className="w-full text-xs border rounded px-2 py-1 mt-1"
                              />
                            </div>
                            {attendance[teacher.id] === "present" && (
                              <div>
                                <label className="text-xs text-gray-600">Check Out</label>
                                <input
                                  type="time"
                                  value={checkOutTimes[teacher.id] || ""}
                                  onChange={(e) => handleCheckOutTimeChange(teacher.id, e.target.value)}
                                  className="w-full text-xs border rounded px-2 py-1 mt-1"
                                />
                              </div>
                            )}
                          </div>
                        )}

                        {(attendance[teacher.id] === "leave" || attendance[teacher.id] === "half-day-leave") && (
                          <div className="mb-3">
                            <label className="text-xs text-gray-600">Leave Reason</label>
                            <div className="flex items-center space-x-2 mt-1">
                              <span className="text-xs text-gray-800 flex-1">
                                {leaveReasons[teacher.id] || "No reason provided"}
                              </span>
                              <Button size="sm" variant="ghost" onClick={() => setShowLeaveDialog(teacher.id)}>
                                <MessageSquare className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        )}

                        <div className="grid grid-cols-2 gap-2">
                          <Button
                            size="sm"
                            variant={attendance[teacher.id] === "present" ? "default" : "outline"}
                            onClick={() => handleAttendanceChange(teacher.id, "present")}
                            className="text-xs h-8"
                          >
                            Present
                          </Button>
                          <Button
                            size="sm"
                            variant={attendance[teacher.id] === "late" ? "default" : "outline"}
                            onClick={() => handleAttendanceChange(teacher.id, "late")}
                            className="text-xs h-8"
                          >
                            Late
                          </Button>
                          <Button
                            size="sm"
                            variant={attendance[teacher.id] === "leave" ? "default" : "outline"}
                            onClick={() => handleAttendanceChange(teacher.id, "leave")}
                            className="text-xs h-8"
                          >
                            Leave
                          </Button>
                          <Button
                            size="sm"
                            variant={attendance[teacher.id] === "half-day-leave" ? "default" : "outline"}
                            onClick={() => handleAttendanceChange(teacher.id, "half-day-leave")}
                            className="text-xs h-8"
                          >
                            Half Day
                          </Button>
                        </div>
                        <Button
                          size="sm"
                          variant={attendance[teacher.id] === "absent" ? "destructive" : "outline"}
                          onClick={() => handleAttendanceChange(teacher.id, "absent")}
                          className="text-xs h-8 w-full mt-2"
                        >
                          Absent
                        </Button>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          )}

          {viewMode === "monthly" && (
            <>
              {/* Month Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg md:text-xl">Monthly Statistics</CardTitle>
                  <CardDescription>View teacher attendance statistics by month</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Month & Year</label>
                      <input
                        type="month"
                        value={selectedMonth}
                        onChange={(e) => setSelectedMonth(e.target.value)}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Monthly Stats Table */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg md:text-xl">Teacher Monthly Attendance Report</CardTitle>
                  <CardDescription>
                    Attendance statistics for{" "}
                    {new Date(selectedMonth + "-01").toLocaleDateString("en-US", { month: "long", year: "numeric" })}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Desktop Table View */}
                  <div className="hidden md:block rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Teacher Name</TableHead>
                          <TableHead>Employee ID</TableHead>
                          <TableHead>Present Days</TableHead>
                          <TableHead>Late Days</TableHead>
                          <TableHead>Leave Days</TableHead>
                          <TableHead>Half Day Leave</TableHead>
                          <TableHead>Absent Days</TableHead>
                          <TableHead>Attendance %</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {teachers.map((teacher) => {
                          const stats = calculateMonthlyStats(teacher.id)
                          return (
                            <TableRow key={teacher.id}>
                              <TableCell className="font-medium">{teacher.name}</TableCell>
                              <TableCell className="font-mono">{teacher.employeeId}</TableCell>
                              <TableCell>
                                <Badge variant="outline" className="text-green-600 bg-green-50">
                                  {stats.presentDays}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className="text-yellow-600 bg-yellow-50">
                                  {stats.lateDays}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className="text-blue-600 bg-blue-50">
                                  {stats.leaveDays}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className="text-purple-600 bg-purple-50">
                                  {stats.halfDayLeaveDays}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className="text-red-600 bg-red-50">
                                  {stats.absentDays}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={
                                    stats.attendancePercentage >= 90
                                      ? "text-green-600 bg-green-50"
                                      : stats.attendancePercentage >= 75
                                        ? "text-yellow-600 bg-yellow-50"
                                        : "text-red-600 bg-red-50"
                                  }
                                >
                                  {stats.attendancePercentage}%
                                </Badge>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Mobile Card View */}
                  <div className="md:hidden space-y-3">
                    {teachers.map((teacher) => {
                      const stats = calculateMonthlyStats(teacher.id)
                      return (
                        <Card key={teacher.id} className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex-1 min-w-0">
                              <h3 className="font-medium text-gray-900 truncate">{teacher.name}</h3>
                              <p className="text-xs text-gray-400 font-mono">{teacher.employeeId}</p>
                            </div>
                            <Badge
                              variant="outline"
                              className={`text-xs ${
                                stats.attendancePercentage >= 90
                                  ? "text-green-600 bg-green-50"
                                  : stats.attendancePercentage >= 75
                                    ? "text-yellow-600 bg-yellow-50"
                                    : "text-red-600 bg-red-50"
                              }`}
                            >
                              {stats.attendancePercentage}%
                            </Badge>
                          </div>

                          <div className="grid grid-cols-3 gap-2 mb-2">
                            <div className="text-center">
                              <Badge variant="outline" className="text-green-600 bg-green-50 text-xs">
                                {stats.presentDays}
                              </Badge>
                              <p className="text-xs text-gray-600 mt-1">Present</p>
                            </div>
                            <div className="text-center">
                              <Badge variant="outline" className="text-yellow-600 bg-yellow-50 text-xs">
                                {stats.lateDays}
                              </Badge>
                              <p className="text-xs text-gray-600 mt-1">Late</p>
                            </div>
                            <div className="text-center">
                              <Badge variant="outline" className="text-blue-600 bg-blue-50 text-xs">
                                {stats.leaveDays}
                              </Badge>
                              <p className="text-xs text-gray-600 mt-1">Leave</p>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="text-center">
                              <Badge variant="outline" className="text-purple-600 bg-purple-50 text-xs">
                                {stats.halfDayLeaveDays}
                              </Badge>
                              <p className="text-xs text-gray-600 mt-1">Half Day</p>
                            </div>
                            <div className="text-center">
                              <Badge variant="outline" className="text-red-600 bg-red-50 text-xs">
                                {stats.absentDays}
                              </Badge>
                              <p className="text-xs text-gray-600 mt-1">Absent</p>
                            </div>
                          </div>
                        </Card>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </>
      )}

      {user?.role !== "admin" && (
        <div className="space-y-6">
          <Alert className="border-red-200 bg-red-50">
            <Shield className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <strong>Access Denied:</strong> Only administrators can access the Teacher Attendance System.
            </AlertDescription>
          </Alert>
        </div>
      )}

      <Dialog open={!!showLeaveDialog} onOpenChange={() => setShowLeaveDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Leave Reason</DialogTitle>
            <DialogDescription>Please provide a reason for the leave request.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="Enter leave reason (e.g., Medical appointment, Personal emergency, Family function)"
              value={showLeaveDialog ? leaveReasons[showLeaveDialog] || "" : ""}
              onChange={(e) => {
                if (showLeaveDialog) {
                  setLeaveReasons((prev) => ({
                    ...prev,
                    [showLeaveDialog]: e.target.value,
                  }))
                }
              }}
              rows={3}
            />
            <div className="flex gap-2">
              <Button
                onClick={() => {
                  if (showLeaveDialog) {
                    handleLeaveReasonSubmit(showLeaveDialog, leaveReasons[showLeaveDialog] || "")
                  }
                }}
                className="flex-1"
              >
                Save Reason
              </Button>
              <Button variant="outline" onClick={() => setShowLeaveDialog(null)} className="flex-1">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
