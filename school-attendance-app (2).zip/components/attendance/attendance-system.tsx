"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  Users,
  Save,
  Send,
  AlertTriangle,
  Edit3,
  FileText,
  UserX,
} from "lucide-react"

interface Student {
  id: string
  name: string
  rollNumber: string
  class: string
}

interface AttendanceRecord {
  studentId: string
  date: string
  status: "present" | "absent" | "late" | "leave" | "half-day-leave"
  markedAt: string
  markedBy: string
  comment?: string // Added comment field for leave reasons
}

interface AttendanceSession {
  id: string
  class: string
  date: string
  status: "draft" | "submitted" | "locked"
  submittedAt?: string
  editableUntil?: string
  totalStudents: number
  presentCount: number
  absentCount: number
  lateCount: number
  leaveCount: number
  halfDayLeaveCount: number // Added half-day leave count
}

export function AttendanceSystem() {
  const { user } = useAuth()
  const [selectedClass, setSelectedClass] = useState("")
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])
  const [attendance, setAttendance] = useState<
    Record<string, "present" | "absent" | "late" | "leave" | "half-day-leave">
  >({})
  const [comments, setComments] = useState<Record<string, string>>({}) // Added comments state
  const [currentSession, setCurrentSession] = useState<AttendanceSession | null>(null)
  const [isEditable, setIsEditable] = useState(true)
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null)
  const [showNotificationPreview, setShowNotificationPreview] = useState(false)
  const [showAbsentStudents, setShowAbsentStudents] = useState(false) // Added absent students view
  const [selectedStudentForComment, setSelectedStudentForComment] = useState<string | null>(null) // For comment dialog

  // Mock students data
  const students: Student[] = [
    { id: "1", name: "Aarav Sharma", rollNumber: "5A001", class: "Class 5A" },
    { id: "2", name: "Priya Patel", rollNumber: "5A002", class: "Class 5A" },
    { id: "3", name: "Arjun Kumar", rollNumber: "5A003", class: "Class 5A" },
    { id: "4", name: "Ananya Singh", rollNumber: "5A004", class: "Class 5A" },
    { id: "5", name: "Rohan Gupta", rollNumber: "5A005", class: "Class 5A" },
    { id: "6", name: "Kavya Reddy", rollNumber: "5B001", class: "Class 5B" },
    { id: "7", name: "Aditya Joshi", rollNumber: "5B002", class: "Class 5B" },
    { id: "8", name: "Ishita Mehta", rollNumber: "5B003", class: "Class 5B" },
  ]

  const availableClasses =
    user?.role === "admin" ? ["Class 5A", "Class 5B", "Class 6A", "Class 6B"] : user?.classes || []

  const filteredStudents = students.filter((student) => (selectedClass ? student.class === selectedClass : false))

  useEffect(() => {
    if (selectedClass && selectedDate) {
      const sessionKey = `${selectedClass}-${selectedDate}`
      const existingSession = localStorage.getItem(`attendance-session-${sessionKey}`)

      if (existingSession) {
        const session: AttendanceSession = JSON.parse(existingSession)
        setCurrentSession(session)

        const existingAttendance = localStorage.getItem(`attendance-${sessionKey}`)
        const existingComments = localStorage.getItem(`attendance-comments-${sessionKey}`) // Load comments
        if (existingAttendance) {
          setAttendance(JSON.parse(existingAttendance))
        }
        if (existingComments) {
          setComments(JSON.parse(existingComments))
        }

        if (session.status === "submitted" && session.editableUntil) {
          const editableUntil = new Date(session.editableUntil)
          const now = new Date()

          const canEdit = user?.role === "admin" || now < editableUntil
          setIsEditable(canEdit)

          if (user?.role !== "admin" && now < editableUntil) {
            const remaining = Math.floor((editableUntil.getTime() - now.getTime()) / 1000)
            setTimeRemaining(remaining)
          } else if (user?.role !== "admin") {
            setTimeRemaining(null)
            const lockedSession = { ...session, status: "locked" as const }
            setCurrentSession(lockedSession)
            localStorage.setItem(`attendance-session-${sessionKey}`, JSON.stringify(lockedSession))
          }
        } else {
          setIsEditable(session.status === "draft" || user?.role === "admin")
          setTimeRemaining(null)
        }
      } else {
        const newSession: AttendanceSession = {
          id: `${sessionKey}-${Date.now()}`,
          class: selectedClass,
          date: selectedDate,
          status: "draft",
          totalStudents: filteredStudents.length,
          presentCount: 0,
          absentCount: 0,
          lateCount: 0,
          leaveCount: 0,
          halfDayLeaveCount: 0, // Initialize half-day leave count
        }
        setCurrentSession(newSession)
        setAttendance({})
        setComments({}) // Initialize comments
        setIsEditable(true)
        setTimeRemaining(null)
      }
    }
  }, [selectedClass, selectedDate, filteredStudents.length, user?.role])

  useEffect(() => {
    if (timeRemaining && timeRemaining > 0 && user?.role !== "admin") {
      const timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev && prev > 1) {
            return prev - 1
          } else {
            setIsEditable(false)
            return null
          }
        })
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [timeRemaining, user?.role])

  const handleAttendanceChange = (
    studentId: string,
    status: "present" | "absent" | "late" | "leave" | "half-day-leave",
  ) => {
    if (!isEditable) return

    setAttendance((prev) => ({
      ...prev,
      [studentId]: status,
    }))

    if (status === "leave" || status === "half-day-leave") {
      setSelectedStudentForComment(studentId)
    }
  }

  const handleCommentSave = (studentId: string, comment: string) => {
    setComments((prev) => ({
      ...prev,
      [studentId]: comment,
    }))
    setSelectedStudentForComment(null)
  }

  const calculateCounts = () => {
    const present = Object.values(attendance).filter((status) => status === "present").length
    const absent = Object.values(attendance).filter((status) => status === "absent").length
    const late = Object.values(attendance).filter((status) => status === "late").length
    const leave = Object.values(attendance).filter((status) => status === "leave").length
    const halfDayLeave = Object.values(attendance).filter((status) => status === "half-day-leave").length // Added half-day leave count
    return { present, absent, late, leave, halfDayLeave }
  }

  const handleSaveDraft = () => {
    if (!currentSession) return

    const counts = calculateCounts()
    const updatedSession: AttendanceSession = {
      ...currentSession,
      presentCount: counts.present,
      absentCount: counts.absent,
      lateCount: counts.late,
      leaveCount: counts.leave,
      halfDayLeaveCount: counts.halfDayLeave, // Save half-day leave count
    }

    const sessionKey = `${selectedClass}-${selectedDate}`
    localStorage.setItem(`attendance-session-${sessionKey}`, JSON.stringify(updatedSession))
    localStorage.setItem(`attendance-${sessionKey}`, JSON.stringify(attendance))
    localStorage.setItem(`attendance-comments-${sessionKey}`, JSON.stringify(comments)) // Save comments
    setCurrentSession(updatedSession)
  }

  const handleSubmitAttendance = () => {
    if (!currentSession) return

    const now = new Date()
    const editableUntil = new Date(now.getTime() + 30 * 60 * 1000) // Changed to 30 minutes
    const counts = calculateCounts()

    const submittedSession: AttendanceSession = {
      ...currentSession,
      status: "submitted",
      submittedAt: now.toISOString(),
      editableUntil: editableUntil.toISOString(),
      presentCount: counts.present,
      absentCount: counts.absent,
      lateCount: counts.late,
      leaveCount: counts.leave,
      halfDayLeaveCount: counts.halfDayLeave, // Include half-day leave count
    }

    const sessionKey = `${selectedClass}-${selectedDate}`
    localStorage.setItem(`attendance-session-${sessionKey}`, JSON.stringify(submittedSession))
    localStorage.setItem(`attendance-${sessionKey}`, JSON.stringify(attendance))
    localStorage.setItem(`attendance-comments-${sessionKey}`, JSON.stringify(comments)) // Save comments

    setCurrentSession(submittedSession)
    if (user?.role !== "admin") {
      setTimeRemaining(30 * 60) // 30 minutes for teachers
    }
    setShowNotificationPreview(true)
    setShowAbsentStudents(true) // Show absent students after submission

    setTimeout(() => {
      setShowNotificationPreview(false)
    }, 5000)
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const getStatusColor = (status: "present" | "absent" | "late" | "leave" | "half-day-leave") => {
    switch (status) {
      case "present":
        return "text-green-600 bg-green-50"
      case "absent":
        return "text-red-600 bg-red-50"
      case "late":
        return "text-yellow-600 bg-yellow-50"
      case "leave":
        return "text-blue-600 bg-blue-50"
      case "half-day-leave": // Added half-day leave styling
        return "text-purple-600 bg-purple-50"
    }
  }

  const getStatusIcon = (status: "present" | "absent" | "late" | "leave" | "half-day-leave") => {
    switch (status) {
      case "present":
        return <CheckCircle className="h-4 w-4" />
      case "absent":
        return <XCircle className="h-4 w-4" />
      case "late":
        return <Clock className="h-4 w-4" />
      case "leave":
        return <FileText className="h-4 w-4" />
      case "half-day-leave": // Added half-day leave icon
        return <Calendar className="h-4 w-4" />
    }
  }

  const getAbsentAndLeaveStudents = () => {
    return filteredStudents.filter(
      (student) =>
        attendance[student.id] === "absent" ||
        attendance[student.id] === "leave" ||
        attendance[student.id] === "half-day-leave", // Include half-day leave students
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header - Made responsive */}
      <div className="px-1">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Student Attendance System</h2>
        <p className="text-gray-600 mt-1 text-sm md:text-base">
          Mark daily attendance with leave management and send notifications to parents
        </p>
      </div>

      {/* Class and Date Selection - Enhanced mobile layout */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg md:text-xl">Select Class & Date</CardTitle>
          <CardDescription className="text-sm">Choose the class and date for attendance marking</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Class</label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a class" />
                </SelectTrigger>
                <SelectContent>
                  {availableClasses.map((className) => (
                    <SelectItem key={className} value={className}>
                      {className}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Date</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Session Status and Notifications */}
      {currentSession && (
        <div className="space-y-3 md:space-y-4">
          {currentSession.status === "submitted" && timeRemaining && user?.role !== "admin" && (
            <Alert>
              <Edit3 className="h-4 w-4" />
              <AlertDescription className="text-sm">
                Attendance submitted successfully! You can still edit for {formatTime(timeRemaining)} more. After this
                time, only admin can edit the attendance.
              </AlertDescription>
            </Alert>
          )}

          {currentSession.status === "submitted" && user?.role === "admin" && (
            <Alert>
              <Edit3 className="h-4 w-4" />
              <AlertDescription className="text-sm">
                Attendance submitted. As an admin, you can edit this attendance at any time.
              </AlertDescription>
            </Alert>
          )}

          {currentSession.status === "locked" && user?.role !== "admin" && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-sm">
                Attendance is locked for {selectedDate}. Only admin can edit now. Parent notifications have been sent.
              </AlertDescription>
            </Alert>
          )}

          {showNotificationPreview && (
            <Alert className="border-green-200 bg-green-50">
              <Send className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800 text-sm">
                <strong>WhatsApp Notifications Sent!</strong> Parents have been notified about their child's attendance.
                <br />
                <em className="text-xs">
                  Example: "Hello Rajesh Sharma, your child Aarav Sharma attended Class 5A today. - SchoolTrack"
                </em>
              </AlertDescription>
            </Alert>
          )}
        </div>
      )}

      {showAbsentStudents && currentSession?.status === "submitted" && getAbsentAndLeaveStudents().length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-lg text-orange-800 flex items-center gap-2">
              <UserX className="h-5 w-5" />
              Absent & Leave Students - {selectedClass}
            </CardTitle>
            <CardDescription className="text-orange-700">Students who are absent or on leave today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {getAbsentAndLeaveStudents().map((student) => (
                <div key={student.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                  <div>
                    <p className="font-medium text-gray-900">{student.name}</p>
                    <p className="text-sm text-gray-500">{student.rollNumber}</p>
                    {comments[student.id] && (
                      <p className="text-xs text-gray-600 mt-1 italic">"{comments[student.id]}"</p>
                    )}
                  </div>
                  <Badge variant="outline" className={getStatusColor(attendance[student.id])}>
                    <div className="flex items-center space-x-1">
                      {getStatusIcon(attendance[student.id])}
                      <span className="capitalize">{attendance[student.id].replace("-", " ")}</span>
                    </div>
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Attendance Summary - Enhanced responsive grid */}
      {selectedClass && currentSession && (
        <div className="grid grid-cols-2 md:grid-cols-6 gap-3 md:gap-4">
          <Card>
            <CardContent className="p-3 md:p-4">
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-600 truncate">Total</p>
                  <p className="text-lg md:text-2xl font-bold">{filteredStudents.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 md:p-4">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 md:h-5 md:w-5 text-green-600 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-600 truncate">Present</p>
                  <p className="text-lg md:text-2xl font-bold text-green-600">{calculateCounts().present}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 md:p-4">
              <div className="flex items-center space-x-2">
                <XCircle className="h-4 w-4 md:h-5 md:w-5 text-red-600 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-600 truncate">Absent</p>
                  <p className="text-lg md:text-2xl font-bold text-red-600">{calculateCounts().absent}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 md:p-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 md:h-5 md:w-5 text-yellow-600 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-600 truncate">Late</p>
                  <p className="text-lg md:text-2xl font-bold text-yellow-600">{calculateCounts().late}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 md:p-4">
              <div className="flex items-center space-x-2">
                <FileText className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-600 truncate">Leave</p>
                  <p className="text-lg md:text-2xl font-bold text-blue-600">{calculateCounts().leave}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 md:p-4">
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4 md:h-5 md:w-5 text-purple-600 flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-600 truncate">Half Day</p>
                  <p className="text-lg md:text-2xl font-bold text-purple-600">{calculateCounts().halfDayLeave}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Attendance Marking - Made fully responsive with mobile cards */}
      {selectedClass && filteredStudents.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <CardTitle className="text-lg md:text-xl">Mark Attendance - {selectedClass}</CardTitle>
                <CardDescription className="text-sm">
                  {new Date(selectedDate).toLocaleDateString("en-US", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </CardDescription>
              </div>
              <div className="flex flex-col sm:flex-row gap-2">
                {isEditable && (
                  <>
                    <Button variant="outline" onClick={handleSaveDraft} className="w-full sm:w-auto bg-transparent">
                      <Save className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Save Draft</span>
                      <span className="sm:hidden">Save</span>
                    </Button>
                    <Button onClick={handleSubmitAttendance} className="w-full sm:w-auto">
                      <Send className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Submit & Notify Parents</span>
                      <span className="sm:hidden">Submit</span>
                    </Button>
                  </>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {/* Desktop Table View */}
            <div className="hidden md:block rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Roll No.</TableHead>
                    <TableHead>Student Name</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Comment</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-mono">{student.rollNumber}</TableCell>
                      <TableCell className="font-medium">{student.name}</TableCell>
                      <TableCell>
                        {attendance[student.id] ? (
                          <Badge variant="outline" className={getStatusColor(attendance[student.id])}>
                            <div className="flex items-center space-x-1">
                              {getStatusIcon(attendance[student.id])}
                              <span className="capitalize">{attendance[student.id].replace("-", " ")}</span>
                            </div>
                          </Badge>
                        ) : (
                          <Badge variant="secondary">Not Marked</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {comments[student.id] && (
                          <span className="text-xs text-gray-600 italic">"{comments[student.id]}"</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          <Button
                            size="sm"
                            variant={attendance[student.id] === "present" ? "default" : "outline"}
                            onClick={() => handleAttendanceChange(student.id, "present")}
                            disabled={!isEditable}
                            className="text-xs"
                          >
                            Present
                          </Button>
                          <Button
                            size="sm"
                            variant={attendance[student.id] === "late" ? "default" : "outline"}
                            onClick={() => handleAttendanceChange(student.id, "late")}
                            disabled={!isEditable}
                            className="text-xs"
                          >
                            Late
                          </Button>
                          <Button
                            size="sm"
                            variant={attendance[student.id] === "absent" ? "destructive" : "outline"}
                            onClick={() => handleAttendanceChange(student.id, "absent")}
                            disabled={!isEditable}
                            className="text-xs"
                          >
                            Absent
                          </Button>
                          <Button
                            size="sm"
                            variant={attendance[student.id] === "leave" ? "default" : "outline"}
                            onClick={() => handleAttendanceChange(student.id, "leave")}
                            disabled={!isEditable}
                            className="text-xs bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                          >
                            Leave
                          </Button>
                          <Button
                            size="sm"
                            variant={attendance[student.id] === "half-day-leave" ? "default" : "outline"}
                            onClick={() => handleAttendanceChange(student.id, "half-day-leave")}
                            disabled={!isEditable}
                            className="text-xs bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
                          >
                            Half Day
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Mobile Card View - Added mobile-friendly attendance cards */}
            <div className="md:hidden space-y-3">
              {filteredStudents.map((student) => (
                <Card key={student.id} className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-gray-900 truncate">{student.name}</h3>
                      <p className="text-sm text-gray-500 font-mono">{student.rollNumber}</p>
                      {comments[student.id] && (
                        <p className="text-xs text-gray-600 mt-1 italic">"{comments[student.id]}"</p>
                      )}
                    </div>
                    <div className="ml-2">
                      {attendance[student.id] ? (
                        <Badge variant="outline" className={`${getStatusColor(attendance[student.id])} text-xs`}>
                          <div className="flex items-center space-x-1">
                            {getStatusIcon(attendance[student.id])}
                            <span className="capitalize">{attendance[student.id].replace("-", " ")}</span>
                          </div>
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-xs">
                          Not Marked
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <Button
                      size="sm"
                      variant={attendance[student.id] === "present" ? "default" : "outline"}
                      onClick={() => handleAttendanceChange(student.id, "present")}
                      disabled={!isEditable}
                      className="text-xs h-8"
                    >
                      Present
                    </Button>
                    <Button
                      size="sm"
                      variant={attendance[student.id] === "late" ? "default" : "outline"}
                      onClick={() => handleAttendanceChange(student.id, "late")}
                      disabled={!isEditable}
                      className="text-xs h-8"
                    >
                      Late
                    </Button>
                    <Button
                      size="sm"
                      variant={attendance[student.id] === "absent" ? "destructive" : "outline"}
                      onClick={() => handleAttendanceChange(student.id, "absent")}
                      disabled={!isEditable}
                      className="text-xs h-8"
                    >
                      Absent
                    </Button>
                    <Button
                      size="sm"
                      variant={attendance[student.id] === "leave" ? "default" : "outline"}
                      onClick={() => handleAttendanceChange(student.id, "leave")}
                      disabled={!isEditable}
                      className="text-xs h-8 bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                    >
                      Leave
                    </Button>
                  </div>
                  <Button
                    size="sm"
                    variant={attendance[student.id] === "half-day-leave" ? "default" : "outline"}
                    onClick={() => handleAttendanceChange(student.id, "half-day-leave")}
                    disabled={!isEditable}
                    className="text-xs h-8 w-full bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
                  >
                    Half Day Leave
                  </Button>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={selectedStudentForComment !== null} onOpenChange={() => setSelectedStudentForComment(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Leave Reason</DialogTitle>
            <DialogDescription>
              Please provide a reason for{" "}
              {selectedStudentForComment && filteredStudents.find((s) => s.id === selectedStudentForComment)?.name}'s
              leave.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Textarea
              placeholder="Enter leave reason (e.g., Medical appointment, Family emergency, etc.)"
              value={selectedStudentForComment ? comments[selectedStudentForComment] || "" : ""}
              onChange={(e) => {
                if (selectedStudentForComment) {
                  setComments((prev) => ({
                    ...prev,
                    [selectedStudentForComment]: e.target.value,
                  }))
                }
              }}
              className="min-h-[100px]"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedStudentForComment(null)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (selectedStudentForComment) {
                  handleCommentSave(selectedStudentForComment, comments[selectedStudentForComment] || "")
                }
              }}
            >
              Save Reason
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Empty States - Enhanced mobile layout */}
      {selectedClass && filteredStudents.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 text-sm md:text-base">No students found for the selected class.</p>
          </CardContent>
        </Card>
      )}

      {!selectedClass && (
        <Card>
          <CardContent className="text-center py-8">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 text-sm md:text-base">Please select a class to start marking attendance.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
