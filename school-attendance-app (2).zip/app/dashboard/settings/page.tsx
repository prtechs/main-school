"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  CalendarIcon,
  Plus,
  Trash2,
  Edit,
  Save,
  X,
  School,
  Users,
  Calendar as CalendarIconLarge,
  Settings as SettingsIcon,
  UserCheck,
} from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

export default function SettingsPage() {
  const [schoolInfo, setSchoolInfo] = useState({
    name: "Springfield Elementary School",
    address: "123 Education Street, Springfield",
    phone: "+1 (555) 123-4567",
    email: "admin@springfield-elementary.edu",
    principal: "Dr. Sarah Johnson",
  })

  const [classes, setClasses] = useState([
    { id: 1, name: "Grade 1A", teacher: "Ms. Smith", students: 25 },
    { id: 2, name: "Grade 1B", teacher: "Mr. Johnson", students: 23 },
    { id: 3, name: "Grade 2A", teacher: "Mrs. Davis", students: 27 },
    { id: 4, name: "Grade 2B", teacher: "Ms. Wilson", students: 24 },
  ])

  const [students, setStudents] = useState([
    { id: 1, name: "John Doe", class: "Grade 1A", parentEmail: "john.parent@email.com", phone: "+1 (555) 111-1111" },
    { id: 2, name: "Jane Smith", class: "Grade 1A", parentEmail: "jane.parent@email.com", phone: "+1 (555) 222-2222" },
    {
      id: 3,
      name: "Mike Johnson",
      class: "Grade 1B",
      parentEmail: "mike.parent@email.com",
      phone: "+1 (555) 333-3333",
    },
  ])

  const [users, setUsers] = useState([
    { id: 1, name: "Admin User", email: "admin@school.com", role: "admin" },
    { id: 2, name: "Ms. Smith", email: "smith@school.com", role: "teacher" },
    { id: 3, name: "Mr. Johnson", email: "johnson@school.com", role: "teacher" },
  ])

  const [holidays, setHolidays] = useState([
    { id: 1, date: new Date("2024-12-25"), name: "Christmas Day", reason: "National Holiday", type: "both" },
    { id: 2, date: new Date("2024-01-01"), name: "New Year Day", reason: "National Holiday", type: "both" },
    { id: 3, date: new Date("2024-07-04"), name: "Independence Day", reason: "National Holiday", type: "both" },
  ])

  const [editingClass, setEditingClass] = useState(null)
  const [editingStudent, setEditingStudent] = useState(null)
  const [editingUser, setEditingUser] = useState(null)
  const [newHoliday, setNewHoliday] = useState({ date: null, name: "", reason: "", type: "both" })
  const [showAddHoliday, setShowAddHoliday] = useState(false)

  const handleSaveSchoolInfo = () => {
    // Save school information
    console.log("School info saved:", schoolInfo)
  }

  const handleAddClass = () => {
    const newClass = {
      id: classes.length + 1,
      name: "",
      teacher: "",
      students: 0,
    }
    setClasses([...classes, newClass])
    setEditingClass(newClass.id)
  }

  const handleSaveClass = (classId) => {
    setEditingClass(null)
    console.log("Class saved")
  }

  const handleDeleteClass = (classId) => {
    setClasses(classes.filter((c) => c.id !== classId))
  }

  const handleAddStudent = () => {
    const newStudent = {
      id: students.length + 1,
      name: "",
      class: "",
      parentEmail: "",
      phone: "",
    }
    setStudents([...students, newStudent])
    setEditingStudent(newStudent.id)
  }

  const handleSaveStudent = (studentId) => {
    setEditingStudent(null)
    console.log("Student saved")
  }

  const handleDeleteStudent = (studentId) => {
    setStudents(students.filter((s) => s.id !== studentId))
  }

  const handleAddUser = () => {
    const newUser = {
      id: users.length + 1,
      name: "",
      email: "",
      role: "teacher",
    }
    setUsers([...users, newUser])
    setEditingUser(newUser.id)
  }

  const handleSaveUser = (userId) => {
    setEditingUser(null)
    console.log("User saved")
  }

  const handleDeleteUser = (userId) => {
    setUsers(users.filter((u) => u.id !== userId))
  }

  const handleAddHoliday = () => {
    if (newHoliday.date && newHoliday.name && newHoliday.reason) {
      const holiday = {
        id: holidays.length + 1,
        ...newHoliday,
      }
      setHolidays([...holidays, holiday])
      setNewHoliday({ date: null, name: "", reason: "", type: "both" })
      setShowAddHoliday(false)
    }
  }

  const handleDeleteHoliday = (holidayId) => {
    setHolidays(holidays.filter((h) => h.id !== holidayId))
  }

  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <SettingsIcon className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600">Manage school information, classes, students, and system settings</p>
        </div>
      </div>

      <Tabs defaultValue="school" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="school" className="flex items-center gap-2">
            <School className="h-4 w-4" />
            School Info
          </TabsTrigger>
          <TabsTrigger value="classes" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Classes
          </TabsTrigger>
          <TabsTrigger value="students" className="flex items-center gap-2">
            <UserCheck className="h-4 w-4" />
            Students
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Users & Roles
          </TabsTrigger>
          <TabsTrigger value="holidays" className="flex items-center gap-2">
            <CalendarIconLarge className="h-4 w-4" />
            Holidays
          </TabsTrigger>
        </TabsList>

        {/* School Information Tab */}
        <TabsContent value="school">
          <Card>
            <CardHeader>
              <CardTitle>School Information</CardTitle>
              <CardDescription>Manage basic school information and contact details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="schoolName">School Name</Label>
                  <Input
                    id="schoolName"
                    value={schoolInfo.name}
                    onChange={(e) => setSchoolInfo({ ...schoolInfo, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="principal">Principal</Label>
                  <Input
                    id="principal"
                    value={schoolInfo.principal}
                    onChange={(e) => setSchoolInfo({ ...schoolInfo, principal: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={schoolInfo.email}
                    onChange={(e) => setSchoolInfo({ ...schoolInfo, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={schoolInfo.phone}
                    onChange={(e) => setSchoolInfo({ ...schoolInfo, phone: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  value={schoolInfo.address}
                  onChange={(e) => setSchoolInfo({ ...schoolInfo, address: e.target.value })}
                />
              </div>
              <Button onClick={handleSaveSchoolInfo} className="w-full md:w-auto">
                <Save className="h-4 w-4 mr-2" />
                Save School Information
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Classes Tab */}
        <TabsContent value="classes">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Class Management</CardTitle>
                <CardDescription>Add, edit, and manage school classes</CardDescription>
              </div>
              <Button onClick={handleAddClass}>
                <Plus className="h-4 w-4 mr-2" />
                Add Class
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {classes.map((classItem) => (
                  <div key={classItem.id} className="flex items-center justify-between p-4 border rounded-lg">
                    {editingClass === classItem.id ? (
                      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Input
                          placeholder="Class Name"
                          value={classItem.name}
                          onChange={(e) => {
                            const updated = classes.map((c) =>
                              c.id === classItem.id ? { ...c, name: e.target.value } : c,
                            )
                            setClasses(updated)
                          }}
                        />
                        <Input
                          placeholder="Teacher Name"
                          value={classItem.teacher}
                          onChange={(e) => {
                            const updated = classes.map((c) =>
                              c.id === classItem.id ? { ...c, teacher: e.target.value } : c,
                            )
                            setClasses(updated)
                          }}
                        />
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => handleSaveClass(classItem.id)}>
                            <Save className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setEditingClass(null)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex-1">
                          <h3 className="font-semibold">{classItem.name}</h3>
                          <p className="text-sm text-gray-600">Teacher: {classItem.teacher}</p>
                          <p className="text-sm text-gray-600">Students: {classItem.students}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => setEditingClass(classItem.id)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleDeleteClass(classItem.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Students Tab */}
        <TabsContent value="students">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Student Management</CardTitle>
                <CardDescription>Add, edit, and manage student information</CardDescription>
              </div>
              <Button onClick={handleAddStudent}>
                <Plus className="h-4 w-4 mr-2" />
                Add Student
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {students.map((student) => (
                  <div key={student.id} className="flex items-center justify-between p-4 border rounded-lg">
                    {editingStudent === student.id ? (
                      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <Input
                          placeholder="Student Name"
                          value={student.name}
                          onChange={(e) => {
                            const updated = students.map((s) =>
                              s.id === student.id ? { ...s, name: e.target.value } : s,
                            )
                            setStudents(updated)
                          }}
                        />
                        <Select
                          value={student.class}
                          onValueChange={(value) => {
                            const updated = students.map((s) => (s.id === student.id ? { ...s, class: value } : s))
                            setStudents(updated)
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select Class" />
                          </SelectTrigger>
                          <SelectContent>
                            {classes.map((classItem) => (
                              <SelectItem key={classItem.id} value={classItem.name}>
                                {classItem.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input
                          placeholder="Parent Email"
                          type="email"
                          value={student.parentEmail}
                          onChange={(e) => {
                            const updated = students.map((s) =>
                              s.id === student.id ? { ...s, parentEmail: e.target.value } : s,
                            )
                            setStudents(updated)
                          }}
                        />
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => handleSaveStudent(student.id)}>
                            <Save className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setEditingStudent(null)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex-1">
                          <h3 className="font-semibold">{student.name}</h3>
                          <p className="text-sm text-gray-600">Class: {student.class}</p>
                          <p className="text-sm text-gray-600">Parent: {student.parentEmail}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => setEditingStudent(student.id)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleDeleteStudent(student.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Users & Roles Tab */}
        <TabsContent value="users">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>User Management & Role Assignment</CardTitle>
                <CardDescription>Manage users and assign roles (Admin/Teacher)</CardDescription>
              </div>
              <Button onClick={handleAddUser}>
                <Plus className="h-4 w-4 mr-2" />
                Add User
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {users.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                    {editingUser === user.id ? (
                      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Input
                          placeholder="Full Name"
                          value={user.name}
                          onChange={(e) => {
                            const updated = users.map((u) => (u.id === user.id ? { ...u, name: e.target.value } : u))
                            setUsers(updated)
                          }}
                        />
                        <Input
                          placeholder="Email"
                          type="email"
                          value={user.email}
                          onChange={(e) => {
                            const updated = users.map((u) => (u.id === user.id ? { ...u, email: e.target.value } : u))
                            setUsers(updated)
                          }}
                        />
                        <div className="flex gap-2">
                          <Select
                            value={user.role}
                            onValueChange={(value) => {
                              const updated = users.map((u) => (u.id === user.id ? { ...u, role: value } : u))
                              setUsers(updated)
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="admin">Admin</SelectItem>
                              <SelectItem value="teacher">Teacher</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button size="sm" onClick={() => handleSaveUser(user.id)}>
                            <Save className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setEditingUser(null)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex-1">
                          <h3 className="font-semibold">{user.name}</h3>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <Badge variant={user.role === "admin" ? "default" : "secondary"} className="mt-1">
                            {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                          </Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => setEditingUser(user.id)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleDeleteUser(user.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Holidays Tab */}
        <TabsContent value="holidays">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Holiday Management</CardTitle>
                <CardDescription>
                  Set holidays, festivals, and special events for teachers and students separately
                </CardDescription>
              </div>
              <Button onClick={() => setShowAddHoliday(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Holiday
              </Button>
            </CardHeader>
            <CardContent>
              {showAddHoliday && (
                <div className="mb-6 p-4 border rounded-lg bg-gray-50">
                  <h3 className="font-semibold mb-4">Add New Holiday</h3>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label>Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !newHoliday.date && "text-muted-foreground",
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {newHoliday.date ? format(newHoliday.date, "PPP") : "Pick a date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={newHoliday.date}
                            onSelect={(date) => setNewHoliday({ ...newHoliday, date })}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div className="space-y-2">
                      <Label>Holiday Name</Label>
                      <Input
                        placeholder="e.g., Christmas Day"
                        value={newHoliday.name}
                        onChange={(e) => setNewHoliday({ ...newHoliday, name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Reason</Label>
                      <Input
                        placeholder="e.g., National Holiday"
                        value={newHoliday.reason}
                        onChange={(e) => setNewHoliday({ ...newHoliday, reason: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Applies To</Label>
                      <Select
                        value={newHoliday.type || "both"}
                        onValueChange={(value) => setNewHoliday({ ...newHoliday, type: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="both">Teachers & Students</SelectItem>
                          <SelectItem value="teachers">Teachers Only</SelectItem>
                          <SelectItem value="students">Students Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button onClick={handleAddHoliday}>
                      <Save className="h-4 w-4 mr-2" />
                      Add Holiday
                    </Button>
                    <Button variant="outline" onClick={() => setShowAddHoliday(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {holidays.map((holiday) => (
                  <div key={holiday.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold">{holiday.name}</h3>
                        <Badge
                          variant="outline"
                          className={
                            holiday.type === "teachers"
                              ? "text-blue-600 bg-blue-50"
                              : holiday.type === "students"
                                ? "text-green-600 bg-green-50"
                                : "text-purple-600 bg-purple-50"
                          }
                        >
                          {holiday.type === "teachers"
                            ? "Teachers Only"
                            : holiday.type === "students"
                              ? "Students Only"
                              : "Teachers & Students"}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">Date: {format(holiday.date, "PPP")}</p>
                      <p className="text-sm text-gray-600">Reason: {holiday.reason}</p>
                    </div>
                    <Button size="sm" variant="destructive" onClick={() => handleDeleteHoliday(holiday.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
