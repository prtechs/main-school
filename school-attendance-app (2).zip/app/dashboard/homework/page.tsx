import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { HomeworkSystem } from "@/components/homework/homework-system"

export default function HomeworkPage() {
  return (
    <DashboardLayout>
      <HomeworkSystem />
    </DashboardLayout>
  )
}
