import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { StudentManagement } from "@/components/students/student-management"

export default function StudentsPage() {
  return (
    <DashboardLayout>
      <StudentManagement />
    </DashboardLayout>
  )
}
