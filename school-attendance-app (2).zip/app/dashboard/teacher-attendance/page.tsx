import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { TeacherAttendanceSystem } from "@/components/attendance/teacher-attendance-system"

export default function TeacherAttendancePage() {
  return (
    <DashboardLayout>
      <TeacherAttendanceSystem />
    </DashboardLayout>
  )
}
