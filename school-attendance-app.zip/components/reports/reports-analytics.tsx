"use client"

import { useState } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import {
  TrendingUp,
  TrendingDown,
  Users,
  Calendar,
  BookOpen,
  Award,
  Download,
  BarChart3,
  PieChartIcon,
  Send,
  Mail,
  CheckCircle,
  Clock,
  XCircle,
  FileText,
  Eye,
  CalendarDays,
} from "lucide-react"

interface StudentPerformance {
  studentId: string
  name: string
  rollNumber: string
  class: string
  weeklyTests: number[]
  monthlyTests: number[]
  quarterlyTests: number[]
  attendanceRate: number
  currentGrade: string
  trend: "improving" | "declining" | "stable"
  parentEmail: string
  dailyAttendance: { date: string; status: "present" | "absent" | "late" | "leave" }[]
}

interface ClassAnalytics {
  class: string
  totalStudents: number
  averageAttendance: number
  averagePerformance: number
  topPerformers: number
  needsAttention: number
  dailyStats: { date: string; present: number; absent: number; late: number; leave: number }[]
}

interface AttendanceReport {
  id: string
  title: string
  type: "daily" | "weekly" | "monthly"
  classes: string[]
  generatedAt: string
  sentTo: string[]
  status: "draft" | "sent"
  data: {
    totalStudents: number
    presentPercentage: number
    absentPercentage: number
    latePercentage: number
    leavePercentage: number
  }
}

export function ReportsAnalytics() {
  const { user } = useAuth()
  const [selectedClass, setSelectedClass] = useState("all")
  const [selectedPeriod, setSelectedPeriod] = useState("monthly")
  const [activeTab, setActiveTab] = useState("overview")
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false)
  const [selectedClasses, setSelectedClasses] = useState<string[]>([])
  const [reportType, setReportType] = useState<"daily" | "weekly" | "monthly">("weekly")
  const [showReportPreview, setShowReportPreview] = useState(false)

  // Enhanced mock data with attendance tracking
  const dailyAttendanceData = [
    { date: "Jan 15", present: 85, absent: 8, late: 5, leave: 2, total: 100 },
    { date: "Jan 16", present: 88, absent: 6, late: 4, leave: 2, total: 100 },
    { date: "Jan 17", present: 82, absent: 10, late: 6, leave: 2, total: 100 },
    { date: "Jan 18", present: 90, absent: 5, late: 3, leave: 2, total: 100 },
    { date: "Jan 19", present: 87, absent: 7, late: 4, leave: 2, total: 100 },
    { date: "Jan 22", present: 89, absent: 6, late: 3, leave: 2, total: 100 },
    { date: "Jan 23", present: 91, absent: 4, late: 3, leave: 2, total: 100 },
  ]

  const weeklyAttendanceData = [
    { week: "Week 1", present: 86, absent: 7, late: 5, leave: 2 },
    { week: "Week 2", present: 89, absent: 6, late: 3, leave: 2 },
    { week: "Week 3", present: 88, absent: 6, late: 4, leave: 2 },
    { week: "Week 4", present: 90, absent: 5, late: 3, leave: 2 },
  ]

  const monthlyAttendanceData = [
    { month: "Sep", present: 92, absent: 4, late: 3, leave: 1 },
    { month: "Oct", present: 89, absent: 6, late: 4, leave: 1 },
    { month: "Nov", present: 94, absent: 3, late: 2, leave: 1 },
    { month: "Dec", present: 91, absent: 5, late: 3, leave: 1 },
    { month: "Jan", present: 88, absent: 6, late: 4, leave: 2 },
  ]

  const performanceData = [
    { month: "Sep", average: 78, class5A: 82, class5B: 74 },
    { month: "Oct", average: 81, class5A: 85, class5B: 77 },
    { month: "Nov", average: 79, class5A: 83, class5B: 75 },
    { month: "Dec", average: 84, class5A: 88, class5B: 80 },
    { month: "Jan", average: 86, class5A: 90, class5B: 82 },
  ]

  const subjectPerformance = [
    { subject: "Mathematics", score: 85, color: "#3b82f6" },
    { subject: "English", score: 78, color: "#10b981" },
    { subject: "Science", score: 82, color: "#f59e0b" },
    { subject: "Social Studies", score: 76, color: "#ef4444" },
    { subject: "Hindi", score: 88, color: "#8b5cf6" },
  ]

  const studentPerformances: StudentPerformance[] = [
    {
      studentId: "1",
      name: "Aarav Sharma",
      rollNumber: "5A001",
      class: "Class 5A",
      weeklyTests: [85, 88, 82, 90],
      monthlyTests: [87, 89, 91],
      quarterlyTests: [88, 92],
      attendanceRate: 96,
      currentGrade: "A",
      trend: "improving",
      parentEmail: "rajesh.sharma@email.com",
      dailyAttendance: [
        { date: "2024-01-15", status: "present" },
        { date: "2024-01-16", status: "present" },
        { date: "2024-01-17", status: "late" },
        { date: "2024-01-18", status: "present" },
        { date: "2024-01-19", status: "present" },
      ],
    },
    {
      studentId: "2",
      name: "Priya Patel",
      rollNumber: "5A002",
      class: "Class 5A",
      weeklyTests: [78, 75, 80, 77],
      monthlyTests: [76, 79, 81],
      quarterlyTests: [78, 80],
      attendanceRate: 92,
      currentGrade: "B+",
      trend: "stable",
      parentEmail: "amit.patel@email.com",
      dailyAttendance: [
        { date: "2024-01-15", status: "present" },
        { date: "2024-01-16", status: "absent" },
        { date: "2024-01-17", status: "present" },
        { date: "2024-01-18", status: "present" },
        { date: "2024-01-19", status: "leave" },
      ],
    },
    {
      studentId: "3",
      name: "Arjun Kumar",
      rollNumber: "5A003",
      class: "Class 5A",
      weeklyTests: [92, 89, 94, 91],
      monthlyTests: [90, 93, 95],
      quarterlyTests: [91, 96],
      attendanceRate: 98,
      currentGrade: "A+",
      trend: "improving",
      parentEmail: "suresh.kumar@email.com",
      dailyAttendance: [
        { date: "2024-01-15", status: "present" },
        { date: "2024-01-16", status: "present" },
        { date: "2024-01-17", status: "present" },
        { date: "2024-01-18", status: "present" },
        { date: "2024-01-19", status: "present" },
      ],
    },
    {
      studentId: "4",
      name: "Ananya Singh",
      rollNumber: "5A004",
      class: "Class 5A",
      weeklyTests: [70, 68, 65, 72],
      monthlyTests: [69, 67, 71],
      quarterlyTests: [68, 70],
      attendanceRate: 88,
      currentGrade: "B",
      trend: "declining",
      parentEmail: "priya.singh@email.com",
      dailyAttendance: [
        { date: "2024-01-15", status: "absent" },
        { date: "2024-01-16", status: "present" },
        { date: "2024-01-17", status: "late" },
        { date: "2024-01-18", status: "present" },
        { date: "2024-01-19", status: "absent" },
      ],
    },
  ]

  const classAnalytics: ClassAnalytics[] = [
    {
      class: "Class 5A",
      totalStudents: 35,
      averageAttendance: 94,
      averagePerformance: 85,
      topPerformers: 12,
      needsAttention: 3,
      dailyStats: dailyAttendanceData.map((day) => ({
        date: day.date,
        present: Math.floor(day.present * 0.35),
        absent: Math.floor(day.absent * 0.35),
        late: Math.floor(day.late * 0.35),
        leave: Math.floor(day.leave * 0.35),
      })),
    },
    {
      class: "Class 5B",
      totalStudents: 33,
      averageAttendance: 91,
      averagePerformance: 82,
      topPerformers: 10,
      needsAttention: 5,
      dailyStats: dailyAttendanceData.map((day) => ({
        date: day.date,
        present: Math.floor(day.present * 0.33),
        absent: Math.floor(day.absent * 0.33),
        late: Math.floor(day.late * 0.33),
        leave: Math.floor(day.leave * 0.33),
      })),
    },
  ]

  const [reports, setReports] = useState<AttendanceReport[]>([
    {
      id: "1",
      title: "Weekly Attendance Report - All Classes",
      type: "weekly",
      classes: ["Class 5A", "Class 5B"],
      generatedAt: "2024-01-20T10:00:00Z",
      sentTo: ["rajesh.sharma@email.com", "amit.patel@email.com", "suresh.kumar@email.com"],
      status: "sent",
      data: {
        totalStudents: 68,
        presentPercentage: 89,
        absentPercentage: 6,
        latePercentage: 3,
        leavePercentage: 2,
      },
    },
  ])

  const availableClasses =
    user?.role === "admin" ? ["Class 5A", "Class 5B", "Class 6A", "Class 6B"] : user?.classes || []

  const filteredStudents = studentPerformances.filter((student) => {
    if (selectedClass === "all") return true
    if (user?.role === "admin") return selectedClass === "all" || student.class === selectedClass
    return user?.classes?.includes(student.class) && (selectedClass === "all" || student.class === selectedClass)
  })

  const handleClassSelection = (className: string, checked: boolean) => {
    if (checked) {
      setSelectedClasses([...selectedClasses, className])
    } else {
      setSelectedClasses(selectedClasses.filter((cls) => cls !== className))
    }
  }

  const handleGenerateReport = (formData: FormData) => {
    const title = formData.get("title") as string
    const message = formData.get("message") as string
    const sendToAll = formData.get("sendToAll") === "on"

    const targetClasses = sendToAll ? availableClasses : selectedClasses
    const targetStudents = studentPerformances.filter((student) => targetClasses.includes(student.class))

    // Calculate attendance percentages
    const totalStudents = targetStudents.length
    const presentCount = targetStudents.filter((s) => s.attendanceRate >= 95).length
    const absentCount = targetStudents.filter((s) => s.attendanceRate < 85).length
    const lateCount = targetStudents.filter((s) => s.attendanceRate >= 85 && s.attendanceRate < 95).length

    const newReport: AttendanceReport = {
      id: Date.now().toString(),
      title,
      type: reportType,
      classes: targetClasses,
      generatedAt: new Date().toISOString(),
      sentTo: targetStudents.map((s) => s.parentEmail),
      status: "sent",
      data: {
        totalStudents,
        presentPercentage: Math.round((presentCount / totalStudents) * 100),
        absentPercentage: Math.round((absentCount / totalStudents) * 100),
        latePercentage: Math.round((lateCount / totalStudents) * 100),
        leavePercentage: 2, // Mock data
      },
    }

    setReports([newReport, ...reports])
    setIsReportDialogOpen(false)
    setSelectedClasses([])
    setShowReportPreview(true)

    setTimeout(() => {
      setShowReportPreview(false)
    }, 5000)
  }

  const getAttendanceData = () => {
    switch (selectedPeriod) {
      case "weekly":
        return weeklyAttendanceData
      case "monthly":
        return monthlyAttendanceData
      default:
        return dailyAttendanceData
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "improving":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "declining":
        return <TrendingDown className="h-4 w-4 text-red-600" />
      default:
        return <div className="h-4 w-4 bg-gray-400 rounded-full" />
    }
  }

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case "improving":
        return "text-green-600 bg-green-50"
      case "declining":
        return "text-red-600 bg-red-50"
      default:
        return "text-gray-600 bg-gray-50"
    }
  }

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case "A+":
        return "bg-green-100 text-green-800"
      case "A":
        return "bg-blue-100 text-blue-800"
      case "B+":
        return "bg-yellow-100 text-yellow-800"
      case "B":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: "present" | "absent" | "late" | "leave") => {
    switch (status) {
      case "present":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "absent":
        return <XCircle className="h-4 w-4 text-red-600" />
      case "late":
        return <Clock className="h-4 w-4 text-yellow-600" />
      case "leave":
        return <FileText className="h-4 w-4 text-blue-600" />
    }
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header - Enhanced mobile layout */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Reports & Analytics</h2>
          <p className="text-gray-600 mt-1 text-sm md:text-base">
            Track attendance, performance and send parent reports
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto">
                <Send className="h-4 w-4 mr-2" />
                Send Parent Report
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Generate Parent Report</DialogTitle>
                <DialogDescription>Create and send attendance reports to parents</DialogDescription>
              </DialogHeader>
              <form action={handleGenerateReport} className="space-y-4">
                <div>
                  <Label htmlFor="title">Report Title</Label>
                  <Input id="title" name="title" placeholder="e.g., Weekly Attendance Report" required />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="reportType">Report Type</Label>
                    <Select
                      value={reportType}
                      onValueChange={(value: "daily" | "weekly" | "monthly") => setReportType(value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily Report</SelectItem>
                        <SelectItem value="weekly">Weekly Report</SelectItem>
                        <SelectItem value="monthly">Monthly Report</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2 pt-6">
                    <Checkbox id="sendToAll" name="sendToAll" />
                    <Label htmlFor="sendToAll" className="text-sm">
                      Send to all classes
                    </Label>
                  </div>
                </div>

                <div>
                  <Label>Select Classes (if not sending to all)</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {availableClasses.map((className) => (
                      <div key={className} className="flex items-center space-x-2">
                        <Checkbox
                          id={className}
                          checked={selectedClasses.includes(className)}
                          onCheckedChange={(checked) => handleClassSelection(className, checked as boolean)}
                        />
                        <Label htmlFor={className} className="text-sm">
                          {className}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="message">Custom Message (optional)</Label>
                  <Textarea id="message" name="message" placeholder="Add a personal message for parents..." rows={3} />
                </div>

                <Button type="submit" className="w-full">
                  <Mail className="h-4 w-4 mr-2" />
                  Generate & Send Report
                </Button>
              </form>
            </DialogContent>
          </Dialog>
          <Button variant="outline" className="w-full sm:w-auto bg-transparent">
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>

      {/* Report Sent Notification */}
      {showReportPreview && (
        <Alert className="border-green-200 bg-green-50">
          <Send className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800 text-sm">
            <strong>Parent Reports Sent Successfully!</strong> Attendance reports have been sent to all selected
            parents.
            <br />
            <em className="text-xs">
              Example: "Weekly Attendance Report: Your child Aarav has 96% attendance this week. Keep up the good work!
              - SchoolTrack"
            </em>
          </AlertDescription>
        </Alert>
      )}

      {/* Filters - Enhanced mobile layout */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="selectedClass">Class</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {availableClasses.map((className) => (
                    <SelectItem key={className} value={className}>
                      {className}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="selectedPeriod">Time Period</Label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily View</SelectItem>
                  <SelectItem value="weekly">Weekly View</SelectItem>
                  <SelectItem value="monthly">Monthly View</SelectItem>
                  <SelectItem value="quarterly">Quarterly View</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Analytics Tabs - Enhanced mobile layout */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
          <TabsTrigger value="overview" className="text-xs md:text-sm">
            Overview
          </TabsTrigger>
          <TabsTrigger value="attendance" className="text-xs md:text-sm">
            Attendance
          </TabsTrigger>
          <TabsTrigger value="performance" className="text-xs md:text-sm hidden md:flex">
            Performance
          </TabsTrigger>
          <TabsTrigger value="students" className="text-xs md:text-sm hidden md:flex">
            Students
          </TabsTrigger>
          <TabsTrigger value="reports" className="text-xs md:text-sm">
            Reports
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 md:space-y-6">
          {/* Key Metrics - Enhanced mobile grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            <Card>
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm text-gray-600 truncate">Total Students</p>
                    <p className="text-lg md:text-2xl font-bold">
                      {selectedClass === "all"
                        ? classAnalytics.reduce((sum, cls) => sum + cls.totalStudents, 0)
                        : classAnalytics.find((cls) => cls.class === selectedClass)?.totalStudents || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 md:h-5 md:w-5 text-green-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm text-gray-600 truncate">Avg Attendance</p>
                    <p className="text-lg md:text-2xl font-bold text-green-600">
                      {selectedClass === "all"
                        ? Math.round(
                            classAnalytics.reduce((sum, cls) => sum + cls.averageAttendance, 0) / classAnalytics.length,
                          )
                        : classAnalytics.find((cls) => cls.class === selectedClass)?.averageAttendance || 0}
                      %
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-4 w-4 md:h-5 md:w-5 text-purple-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm text-gray-600 truncate">Performance</p>
                    <p className="text-lg md:text-2xl font-bold text-purple-600">
                      {selectedClass === "all"
                        ? Math.round(
                            classAnalytics.reduce((sum, cls) => sum + cls.averagePerformance, 0) /
                              classAnalytics.length,
                          )
                        : classAnalytics.find((cls) => cls.class === selectedClass)?.averagePerformance || 0}
                      %
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center space-x-2">
                  <Award className="h-4 w-4 md:h-5 md:w-5 text-yellow-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm text-gray-600 truncate">Top Performers</p>
                    <p className="text-lg md:text-2xl font-bold text-yellow-600">
                      {selectedClass === "all"
                        ? classAnalytics.reduce((sum, cls) => sum + cls.topPerformers, 0)
                        : classAnalytics.find((cls) => cls.class === selectedClass)?.topPerformers || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Performance Trends - Enhanced mobile layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg md:text-xl flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5" />
                  <span>Performance Trends</span>
                </CardTitle>
                <CardDescription className="text-sm">Monthly average scores comparison</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="average" stroke="#3b82f6" strokeWidth={2} />
                    <Line type="monotone" dataKey="class5A" stroke="#10b981" strokeWidth={2} />
                    <Line type="monotone" dataKey="class5B" stroke="#f59e0b" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg md:text-xl flex items-center space-x-2">
                  <PieChartIcon className="h-5 w-5" />
                  <span>Subject Performance</span>
                </CardTitle>
                <CardDescription className="text-sm">Average scores by subject</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={subjectPerformance}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="score"
                      label={({ subject, score }) => `${subject}: ${score}%`}
                    >
                      {subjectPerformance.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="attendance" className="space-y-4 md:space-y-6">
          {/* Attendance Percentage Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            <Card>
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 md:h-5 md:w-5 text-green-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm text-gray-600 truncate">Present</p>
                    <p className="text-lg md:text-2xl font-bold text-green-600">89%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center space-x-2">
                  <XCircle className="h-4 w-4 md:h-5 md:w-5 text-red-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm text-gray-600 truncate">Absent</p>
                    <p className="text-lg md:text-2xl font-bold text-red-600">6%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 md:h-5 md:w-5 text-yellow-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm text-gray-600 truncate">Late</p>
                    <p className="text-lg md:text-2xl font-bold text-yellow-600">3%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center space-x-2">
                  <FileText className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs md:text-sm text-gray-600 truncate">Leave</p>
                    <p className="text-lg md:text-2xl font-bold text-blue-600">2%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg md:text-xl">
                Attendance Trends - {selectedPeriod.charAt(0).toUpperCase() + selectedPeriod.slice(1)} View
              </CardTitle>
              <CardDescription className="text-sm">
                Attendance patterns over time with percentage breakdown
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={getAttendanceData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey={selectedPeriod === "daily" ? "date" : selectedPeriod === "weekly" ? "week" : "month"}
                  />
                  <YAxis />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="present"
                    stackId="1"
                    stroke="#10b981"
                    fill="#10b981"
                    fillOpacity={0.8}
                  />
                  <Area type="monotone" dataKey="late" stackId="1" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.8} />
                  <Area type="monotone" dataKey="leave" stackId="1" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.8} />
                  <Area
                    type="monotone"
                    dataKey="absent"
                    stackId="1"
                    stroke="#ef4444"
                    fill="#ef4444"
                    fillOpacity={0.8}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4 md:space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg md:text-xl">Class Performance Comparison</CardTitle>
              <CardDescription className="text-sm">Average test scores by class over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="class5A" fill="#3b82f6" name="Class 5A" />
                  <Bar dataKey="class5B" fill="#10b981" name="Class 5B" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="students" className="space-y-4 md:space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg md:text-xl">Individual Student Performance</CardTitle>
              <CardDescription className="text-sm">Detailed performance and attendance tracking</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Desktop Table View */}
              <div className="hidden md:block rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Current Grade</TableHead>
                      <TableHead>Attendance</TableHead>
                      <TableHead>Recent Attendance</TableHead>
                      <TableHead>Trend</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStudents.map((student) => (
                      <TableRow key={student.studentId}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{student.name}</div>
                            <div className="text-sm text-gray-500">{student.rollNumber}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{student.class}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={getGradeColor(student.currentGrade)}>{student.currentGrade}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div
                              className={`w-2 h-2 rounded-full ${
                                student.attendanceRate >= 95
                                  ? "bg-green-500"
                                  : student.attendanceRate >= 90
                                    ? "bg-yellow-500"
                                    : "bg-red-500"
                              }`}
                            />
                            <span>{student.attendanceRate}%</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            {student.dailyAttendance.slice(-5).map((day, index) => (
                              <div key={index} className="flex flex-col items-center">
                                {getStatusIcon(day.status)}
                                <span className="text-xs text-gray-500 mt-1">{new Date(day.date).getDate()}</span>
                              </div>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getTrendIcon(student.trend)}
                            <Badge variant="outline" className={getTrendColor(student.trend)}>
                              {student.trend}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card View */}
              <div className="md:hidden space-y-3">
                {filteredStudents.map((student) => (
                  <Card key={student.studentId} className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-gray-900 truncate">{student.name}</h3>
                        <p className="text-sm text-gray-500">{student.rollNumber}</p>
                        <Badge variant="outline" className="mt-1">
                          {student.class}
                        </Badge>
                      </div>
                      <div className="ml-2 flex flex-col gap-1">
                        <Badge className={getGradeColor(student.currentGrade)}>{student.currentGrade}</Badge>
                        <div className="flex items-center space-x-1 text-sm">
                          <div
                            className={`w-2 h-2 rounded-full ${
                              student.attendanceRate >= 95
                                ? "bg-green-500"
                                : student.attendanceRate >= 90
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                          />
                          <span>{student.attendanceRate}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Recent Attendance:</p>
                        <div className="flex space-x-1">
                          {student.dailyAttendance.slice(-5).map((day, index) => (
                            <div key={index} className="flex flex-col items-center">
                              {getStatusIcon(day.status)}
                              <span className="text-xs text-gray-500 mt-1">{new Date(day.date).getDate()}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {getTrendIcon(student.trend)}
                          <Badge variant="outline" className={getTrendColor(student.trend)}>
                            {student.trend}
                          </Badge>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4 md:space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg md:text-xl">Parent Report History</CardTitle>
              <CardDescription className="text-sm">Previously sent attendance reports to parents</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reports.map((report) => (
                  <div
                    key={report.id}
                    className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg gap-4"
                  >
                    <div className="flex items-start space-x-4">
                      <div className="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full flex-shrink-0">
                        <CalendarDays className="h-5 w-5 text-blue-600" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-medium">{report.title}</p>
                        <p className="text-sm text-gray-500">
                          {report.classes.join(", ")} • {report.sentTo.length} parents
                        </p>
                        <p className="text-xs text-gray-400">{new Date(report.generatedAt).toLocaleString()}</p>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Badge variant="outline" className="text-xs">
                            Present: {report.data.presentPercentage}%
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            Absent: {report.data.absentPercentage}%
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            Late: {report.data.latePercentage}%
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        {report.status}
                      </Badge>
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
