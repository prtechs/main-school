"use client"

import { useState } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Calendar, Clock, Users, Send, Eye, Edit, CheckCircle, Bell, MapPin, Filter } from "lucide-react"

interface ParentMeeting {
  id: string
  title: string
  description: string
  type: "individual" | "group" | "class" | "all-classes" | "school"
  date: string
  time: string
  duration: number // in minutes
  location: string
  organizer: string
  classes?: string[] // For multiple classes or all classes
  students?: string[]
  parents: string[]
  status: "scheduled" | "confirmed" | "completed" | "cancelled"
  reminderSent: boolean
  agenda: string[]
  notes?: string
  priority: "low" | "medium" | "high"
  maxAttendees?: number
}

interface MeetingReminder {
  id: string
  meetingId: string
  sentAt: string
  recipientCount: number
  status: "sent" | "failed"
  type: "initial" | "reminder" | "followup"
}

export function ParentMeetingSystem() {
  const { user } = useAuth()
  const [isAddMeetingOpen, setIsAddMeetingOpen] = useState(false)
  const [selectedMeeting, setSelectedMeeting] = useState<ParentMeeting | null>(null)
  const [showReminderPreview, setShowReminderPreview] = useState(false)
  const [activeTab, setActiveTab] = useState("upcoming")
  const [filterType, setFilterType] = useState<string>("all")
  const [filterClass, setFilterClass] = useState<string>("all")
  const [selectedClasses, setSelectedClasses] = useState<string[]>([])

  // Mock meetings data with enhanced features
  const [meetings, setMeetings] = useState<ParentMeeting[]>([
    {
      id: "1",
      title: "Quarterly Parent-Teacher Conference - All Classes",
      description:
        "School-wide quarterly parent-teacher meeting to discuss student progress and upcoming activities for all classes.",
      type: "all-classes",
      date: "2024-01-25",
      time: "10:00",
      duration: 180,
      location: "School Auditorium",
      organizer: "Sarah Johnson",
      classes: ["Class 5A", "Class 5B", "Class 6A", "Class 6B"],
      parents: ["rajesh.sharma@email.com", "amit.patel@email.com", "suresh.kumar@email.com", "priya.singh@email.com"],
      status: "scheduled",
      reminderSent: false,
      priority: "high",
      maxAttendees: 200,
      agenda: [
        "Welcome and school updates",
        "Review quarterly academic performance across all classes",
        "Discuss upcoming school events and activities",
        "Address parent concerns and feedback",
        "Plan for next quarter activities",
        "Q&A session with principal and teachers",
      ],
    },
    {
      id: "2",
      title: "Individual Meeting - Aarav Sharma Progress",
      description: "One-on-one discussion about Aarav's academic performance and behavior.",
      type: "individual",
      date: "2024-01-22",
      time: "14:30",
      duration: 30,
      location: "Classroom 5A",
      organizer: "Sarah Johnson",
      classes: ["Class 5A"],
      students: ["1"],
      parents: ["rajesh.sharma@email.com"],
      status: "confirmed",
      reminderSent: true,
      priority: "medium",
      agenda: ["Review recent test scores", "Discuss homework completion", "Set improvement goals"],
      notes: "Parent requested meeting to discuss math performance.",
    },
    {
      id: "3",
      title: "Class 5A & 5B Parent Meeting",
      description: "Joint meeting for Class 5A and 5B parents to discuss inter-class activities and coordination.",
      type: "class",
      date: "2024-01-28",
      time: "16:00",
      duration: 90,
      location: "School Conference Room",
      organizer: "Sarah Johnson",
      classes: ["Class 5A", "Class 5B"],
      parents: ["rajesh.sharma@email.com", "amit.patel@email.com", "vikram.singh@email.com"],
      status: "scheduled",
      reminderSent: false,
      priority: "medium",
      maxAttendees: 50,
      agenda: [
        "Coordinate inter-class activities",
        "Plan joint field trips",
        "Discuss shared resources",
        "Parent volunteer coordination",
      ],
    },
    {
      id: "4",
      title: "Annual Sports Day Planning - All Classes",
      description: "Meeting with parent volunteers from all classes to plan the annual sports day event.",
      type: "all-classes",
      date: "2024-02-05",
      time: "15:30",
      duration: 120,
      location: "School Sports Ground",
      organizer: "Physical Education Department",
      classes: ["Class 5A", "Class 5B", "Class 6A", "Class 6B"],
      parents: ["rajesh.sharma@email.com", "amit.patel@email.com", "vikram.singh@email.com", "sunita.reddy@email.com"],
      status: "scheduled",
      reminderSent: false,
      priority: "high",
      maxAttendees: 100,
      agenda: [
        "Finalize sports day schedule for all classes",
        "Assign volunteer responsibilities by class",
        "Discuss equipment and logistics",
        "Plan refreshment arrangements",
        "Safety protocols and medical arrangements",
        "Prize distribution planning",
      ],
    },
  ])

  const [reminders, setReminders] = useState<MeetingReminder[]>([
    {
      id: "1",
      meetingId: "2",
      sentAt: "2024-01-20T09:00:00Z",
      recipientCount: 1,
      status: "sent",
      type: "initial",
    },
  ])

  const availableClasses =
    user?.role === "admin" ? ["Class 5A", "Class 5B", "Class 6A", "Class 6B"] : user?.classes || []

  const filteredMeetings = meetings.filter((meeting) => {
    // Role-based filtering
    if (user?.role !== "admin" && meeting.classes) {
      const hasAccess = meeting.classes.some((cls) => user?.classes?.includes(cls))
      if (!hasAccess) return false
    }

    // Type filtering
    if (filterType !== "all" && meeting.type !== filterType) return false

    // Class filtering
    if (filterClass !== "all") {
      if (!meeting.classes?.includes(filterClass)) return false
    }

    return true
  })

  const handleClassSelection = (className: string, checked: boolean) => {
    if (checked) {
      setSelectedClasses([...selectedClasses, className])
    } else {
      setSelectedClasses(selectedClasses.filter((cls) => cls !== className))
    }
  }

  const handleAddMeeting = (formData: FormData) => {
    const agendaItems = (formData.get("agenda") as string)
      .split("\n")
      .filter((item) => item.trim())
      .map((item) => item.trim())

    const meetingType = formData.get("type") as string
    let classes: string[] = []

    if (meetingType === "all-classes") {
      classes = availableClasses
    } else if (meetingType === "class") {
      classes = selectedClasses
    } else if (formData.get("class")) {
      classes = [formData.get("class") as string]
    }

    const newMeeting: ParentMeeting = {
      id: Date.now().toString(),
      title: formData.get("title") as string,
      description: formData.get("description") as string,
      type: meetingType as "individual" | "group" | "class" | "all-classes" | "school",
      date: formData.get("date") as string,
      time: formData.get("time") as string,
      duration: Number.parseInt(formData.get("duration") as string),
      location: formData.get("location") as string,
      organizer: user?.name || "",
      classes: classes,
      parents: [], // Would be populated based on class/students selected
      status: "scheduled",
      reminderSent: false,
      priority: formData.get("priority") as "low" | "medium" | "high",
      maxAttendees: formData.get("maxAttendees") ? Number.parseInt(formData.get("maxAttendees") as string) : undefined,
      agenda: agendaItems,
    }

    setMeetings([...meetings, newMeeting])
    setIsAddMeetingOpen(false)
    setSelectedClasses([])
  }

  const handleSendReminder = (meetingId: string) => {
    const meeting = meetings.find((m) => m.id === meetingId)
    if (!meeting) return

    // Update meeting reminder status
    setMeetings((prev) => prev.map((m) => (m.id === meetingId ? { ...m, reminderSent: true } : m)))

    // Add reminder record
    const newReminder: MeetingReminder = {
      id: Date.now().toString(),
      meetingId,
      sentAt: new Date().toISOString(),
      recipientCount: meeting.parents.length,
      status: "sent",
      type: "reminder",
    }
    setReminders([...reminders, newReminder])
    setShowReminderPreview(true)

    setTimeout(() => {
      setShowReminderPreview(false)
    }, 5000)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "confirmed":
        return "bg-green-100 text-green-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "individual":
        return "bg-purple-100 text-purple-800"
      case "group":
        return "bg-orange-100 text-orange-800"
      case "class":
        return "bg-blue-100 text-blue-800"
      case "all-classes":
        return "bg-green-100 text-green-800"
      case "school":
        return "bg-indigo-100 text-indigo-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getDaysUntilMeeting = (date: string) => {
    const meetingDate = new Date(date)
    const today = new Date()
    const diffTime = meetingDate.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  const upcomingMeetings = filteredMeetings.filter((meeting) => {
    const daysUntil = getDaysUntilMeeting(meeting.date)
    return daysUntil >= 0 && meeting.status !== "completed" && meeting.status !== "cancelled"
  })

  const pastMeetings = filteredMeetings.filter((meeting) => {
    const daysUntil = getDaysUntilMeeting(meeting.date)
    return daysUntil < 0 || meeting.status === "completed"
  })

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header - Enhanced mobile layout */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Parent Meetings</h2>
          <p className="text-gray-600 mt-1 text-sm md:text-base">Schedule and manage parent-teacher meetings</p>
        </div>
        <Dialog open={isAddMeetingOpen} onOpenChange={setIsAddMeetingOpen}>
          <DialogTrigger asChild>
            <Button className="w-full sm:w-auto">
              <Plus className="h-4 w-4 mr-2" />
              Schedule Meeting
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Schedule New Meeting</DialogTitle>
              <DialogDescription>Create a new parent-teacher meeting</DialogDescription>
            </DialogHeader>
            <form action={handleAddMeeting} className="space-y-4">
              <div>
                <Label htmlFor="title">Meeting Title</Label>
                <Input id="title" name="title" placeholder="e.g., Parent-Teacher Conference" required />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="Brief description of the meeting purpose..."
                  rows={3}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type">Meeting Type</Label>
                  <Select
                    name="type"
                    required
                    onValueChange={(value) => {
                      if (value !== "class") {
                        setSelectedClasses([])
                      }
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="individual">Individual Parent</SelectItem>
                      <SelectItem value="group">Group Meeting</SelectItem>
                      <SelectItem value="class">Specific Classes</SelectItem>
                      <SelectItem value="all-classes">All Classes</SelectItem>
                      <SelectItem value="school">School-wide</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select name="priority" defaultValue="medium">
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Class Selection for Multiple Classes */}
              <div>
                <Label>Select Classes (for specific class meetings)</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {availableClasses.map((className) => (
                    <div key={className} className="flex items-center space-x-2">
                      <Checkbox
                        id={className}
                        checked={selectedClasses.includes(className)}
                        onCheckedChange={(checked) => handleClassSelection(className, checked as boolean)}
                      />
                      <Label htmlFor={className} className="text-sm">
                        {className}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input id="date" name="date" type="date" required />
                </div>
                <div>
                  <Label htmlFor="time">Time</Label>
                  <Input id="time" name="time" type="time" required />
                </div>
                <div>
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input id="duration" name="duration" type="number" placeholder="60" required />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input id="location" name="location" placeholder="e.g., Classroom 5A, School Auditorium" required />
                </div>
                <div>
                  <Label htmlFor="maxAttendees">Max Attendees (optional)</Label>
                  <Input id="maxAttendees" name="maxAttendees" type="number" placeholder="50" />
                </div>
              </div>

              <div>
                <Label htmlFor="agenda">Agenda (one item per line)</Label>
                <Textarea
                  id="agenda"
                  name="agenda"
                  placeholder="Review student progress&#10;Discuss upcoming events&#10;Address parent concerns"
                  rows={4}
                />
              </div>

              <Button type="submit" className="w-full">
                Schedule Meeting
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Reminder Notification */}
      {showReminderPreview && (
        <Alert className="border-green-200 bg-green-50">
          <Send className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800 text-sm">
            <strong>WhatsApp Reminders Sent!</strong> Parents have been notified about the upcoming meeting.
            <br />
            <em className="text-xs">
              Example: "Reminder: Parent-Teacher Conference scheduled for Jan 25, 2024 at 10:00 AM in School Auditorium.
              Please confirm your attendance. - SchoolTrack"
            </em>
          </AlertDescription>
        </Alert>
      )}

      {/* Meeting Statistics - Enhanced mobile grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Card>
          <CardContent className="p-3 md:p-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs md:text-sm text-gray-600 truncate">Upcoming</p>
                <p className="text-lg md:text-2xl font-bold">{upcomingMeetings.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 md:p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4 md:h-5 md:w-5 text-green-600 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs md:text-sm text-gray-600 truncate">This Week</p>
                <p className="text-lg md:text-2xl font-bold">
                  {
                    upcomingMeetings.filter((meeting) => {
                      const daysUntil = getDaysUntilMeeting(meeting.date)
                      return daysUntil >= 0 && daysUntil <= 7
                    }).length
                  }
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 md:p-4">
            <div className="flex items-center space-x-2">
              <Bell className="h-4 w-4 md:h-5 md:w-5 text-yellow-600 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs md:text-sm text-gray-600 truncate">Reminders</p>
                <p className="text-lg md:text-2xl font-bold">{reminders.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 md:p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 md:h-5 md:w-5 text-purple-600 flex-shrink-0" />
              <div className="min-w-0">
                <p className="text-xs md:text-sm text-gray-600 truncate">Parents</p>
                <p className="text-lg md:text-2xl font-bold">
                  {new Set(filteredMeetings.flatMap((meeting) => meeting.parents)).size}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters - Enhanced mobile layout */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="filterType">Meeting Type</Label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="individual">Individual</SelectItem>
                  <SelectItem value="group">Group</SelectItem>
                  <SelectItem value="class">Class</SelectItem>
                  <SelectItem value="all-classes">All Classes</SelectItem>
                  <SelectItem value="school">School-wide</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterClass">Class</Label>
              <Select value={filterClass} onValueChange={setFilterClass}>
                <SelectTrigger>
                  <SelectValue placeholder="All classes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Classes</SelectItem>
                  {availableClasses.map((className) => (
                    <SelectItem key={className} value={className}>
                      {className}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Meeting Management Tabs - Enhanced mobile layout */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upcoming" className="text-xs md:text-sm">
            Upcoming
          </TabsTrigger>
          <TabsTrigger value="past" className="text-xs md:text-sm">
            Past
          </TabsTrigger>
          <TabsTrigger value="reminders" className="text-xs md:text-sm">
            Reminders
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg md:text-xl">Upcoming Meetings</CardTitle>
              <CardDescription className="text-sm">Scheduled parent-teacher meetings</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Desktop Table View */}
              <div className="hidden md:block rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Meeting</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {upcomingMeetings.map((meeting) => {
                      const daysUntil = getDaysUntilMeeting(meeting.date)
                      return (
                        <TableRow key={meeting.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{meeting.title}</div>
                              <div className="text-sm text-gray-500 truncate max-w-xs">{meeting.description}</div>
                              <div className="flex gap-1 mt-1">
                                {meeting.classes?.map((cls) => (
                                  <Badge key={cls} variant="outline" className="text-xs">
                                    {cls}
                                  </Badge>
                                ))}
                                <Badge className={getPriorityColor(meeting.priority)} variant="outline">
                                  {meeting.priority}
                                </Badge>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={getTypeColor(meeting.type)}>
                              {meeting.type === "all-classes" ? "All Classes" : meeting.type}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="flex items-center space-x-1">
                                <Calendar className="h-3 w-3" />
                                <span>{new Date(meeting.date).toLocaleDateString()}</span>
                              </div>
                              <div className="flex items-center space-x-1 text-sm text-gray-500">
                                <Clock className="h-3 w-3" />
                                <span>
                                  {meeting.time} ({meeting.duration}min)
                                </span>
                              </div>
                              <div
                                className={`text-xs ${
                                  daysUntil <= 1 ? "text-red-600" : daysUntil <= 3 ? "text-yellow-600" : "text-gray-500"
                                }`}
                              >
                                {daysUntil === 0 ? "Today" : daysUntil === 1 ? "Tomorrow" : `${daysUntil} days away`}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-1">
                              <MapPin className="h-3 w-3 text-gray-400" />
                              <span className="text-sm">{meeting.location}</span>
                            </div>
                            {meeting.maxAttendees && (
                              <div className="text-xs text-gray-500 mt-1">Max: {meeting.maxAttendees}</div>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              <Badge className={getStatusColor(meeting.status)}>{meeting.status}</Badge>
                              {meeting.reminderSent && (
                                <div className="flex items-center space-x-1 text-xs text-green-600">
                                  <Bell className="h-3 w-3" />
                                  <span>Reminded</span>
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button variant="ghost" size="sm" onClick={() => setSelectedMeeting(meeting)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              {!meeting.reminderSent && (
                                <Button variant="ghost" size="sm" onClick={() => handleSendReminder(meeting.id)}>
                                  <Send className="h-4 w-4" />
                                </Button>
                              )}
                              <Button variant="ghost" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>

              {/* Mobile Card View */}
              <div className="md:hidden space-y-3">
                {upcomingMeetings.map((meeting) => {
                  const daysUntil = getDaysUntilMeeting(meeting.date)
                  return (
                    <Card key={meeting.id} className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-gray-900 truncate">{meeting.title}</h3>
                          <p className="text-sm text-gray-500 mt-1">{meeting.description}</p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {meeting.classes?.slice(0, 2).map((cls) => (
                              <Badge key={cls} variant="outline" className="text-xs">
                                {cls}
                              </Badge>
                            ))}
                            {meeting.classes && meeting.classes.length > 2 && (
                              <Badge variant="outline" className="text-xs">
                                +{meeting.classes.length - 2} more
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="ml-2 flex flex-col gap-1">
                          <Badge className={getTypeColor(meeting.type)} variant="outline">
                            {meeting.type === "all-classes" ? "All" : meeting.type}
                          </Badge>
                          <Badge className={getPriorityColor(meeting.priority)} variant="outline">
                            {meeting.priority}
                          </Badge>
                        </div>
                      </div>

                      <div className="space-y-2 text-sm text-gray-600">
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(meeting.date).toLocaleDateString()}</span>
                          <Clock className="h-4 w-4 ml-2" />
                          <span>
                            {meeting.time} ({meeting.duration}min)
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-4 w-4" />
                          <span>{meeting.location}</span>
                        </div>
                        <div
                          className={`text-xs ${
                            daysUntil <= 1 ? "text-red-600" : daysUntil <= 3 ? "text-yellow-600" : "text-gray-500"
                          }`}
                        >
                          {daysUntil === 0 ? "Today" : daysUntil === 1 ? "Tomorrow" : `${daysUntil} days away`}
                        </div>
                      </div>

                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-2">
                          <Badge className={getStatusColor(meeting.status)}>{meeting.status}</Badge>
                          {meeting.reminderSent && (
                            <div className="flex items-center space-x-1 text-xs text-green-600">
                              <Bell className="h-3 w-3" />
                              <span>Reminded</span>
                            </div>
                          )}
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm" onClick={() => setSelectedMeeting(meeting)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          {!meeting.reminderSent && (
                            <Button variant="ghost" size="sm" onClick={() => handleSendReminder(meeting.id)}>
                              <Send className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </Card>
                  )
                })}
              </div>

              {upcomingMeetings.length === 0 && (
                <div className="text-center py-8 text-gray-500">No upcoming meetings scheduled.</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="past">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg md:text-xl">Past Meetings</CardTitle>
              <CardDescription className="text-sm">Completed and cancelled meetings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Meeting</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pastMeetings.map((meeting) => (
                      <TableRow key={meeting.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{meeting.title}</div>
                            <div className="text-sm text-gray-500">{meeting.description}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getTypeColor(meeting.type)}>
                            {meeting.type === "all-classes" ? "All Classes" : meeting.type}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(meeting.date).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(meeting.status)}>{meeting.status}</Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" onClick={() => setSelectedMeeting(meeting)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reminders">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg md:text-xl">Reminder History</CardTitle>
              <CardDescription className="text-sm">WhatsApp reminders sent to parents</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reminders.map((reminder) => {
                  const meeting = meetings.find((m) => m.id === reminder.meetingId)
                  return (
                    <div key={reminder.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center justify-center w-10 h-10 bg-green-100 rounded-full">
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">{meeting?.title}</p>
                          <p className="text-sm text-gray-500">
                            Sent to {reminder.recipientCount} parents • {new Date(reminder.sentAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        {reminder.status}
                      </Badge>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Meeting Detail Modal - Enhanced mobile layout */}
      {selectedMeeting && (
        <Dialog open={!!selectedMeeting} onOpenChange={() => setSelectedMeeting(null)}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-lg md:text-xl">{selectedMeeting.title}</DialogTitle>
              <DialogDescription className="text-sm">
                {selectedMeeting.type === "all-classes" ? "All Classes" : selectedMeeting.type} meeting
                {selectedMeeting.classes && selectedMeeting.classes.length > 0 && (
                  <span> • {selectedMeeting.classes.join(", ")}</span>
                )}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium mb-2">Meeting Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      <span>{new Date(selectedMeeting.date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <span>
                        {selectedMeeting.time} ({selectedMeeting.duration} minutes)
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span>{selectedMeeting.location}</span>
                    </div>
                    {selectedMeeting.maxAttendees && (
                      <div className="flex items-center space-x-2">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span>Max {selectedMeeting.maxAttendees} attendees</span>
                      </div>
                    )}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Status & Priority</h4>
                  <div className="space-y-2">
                    <Badge className={getStatusColor(selectedMeeting.status)}>{selectedMeeting.status}</Badge>
                    <Badge className={getTypeColor(selectedMeeting.type)}>
                      {selectedMeeting.type === "all-classes" ? "All Classes" : selectedMeeting.type}
                    </Badge>
                    <Badge className={getPriorityColor(selectedMeeting.priority)}>{selectedMeeting.priority}</Badge>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Description</h4>
                <p className="text-gray-700 text-sm">{selectedMeeting.description}</p>
              </div>

              {selectedMeeting.classes && selectedMeeting.classes.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Classes Involved</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedMeeting.classes.map((cls) => (
                      <Badge key={cls} variant="outline">
                        {cls}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {selectedMeeting.agenda.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Agenda</h4>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    {selectedMeeting.agenda.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedMeeting.notes && (
                <div>
                  <h4 className="font-medium mb-2">Notes</h4>
                  <p className="text-gray-700 text-sm">{selectedMeeting.notes}</p>
                </div>
              )}

              <div className="flex flex-col sm:flex-row justify-end gap-2">
                <Button variant="outline" onClick={() => setSelectedMeeting(null)} className="w-full sm:w-auto">
                  Close
                </Button>
                <Button className="w-full sm:w-auto">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Meeting
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
