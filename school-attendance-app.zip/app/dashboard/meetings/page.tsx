import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { ParentMeetingSystem } from "@/components/meetings/parent-meeting-system"

export default function MeetingsPage() {
  return (
    <DashboardLayout>
      <ParentMeetingSystem />
    </DashboardLayout>
  )
}
